<?
///////////////////////////// show errors
ini_set('display_errors', 1); 
error_reporting(E_ALL);
/////////////////////////////
$checkError = ini_get('error_reporting');
error_reporting($checkError  ^ E_NOTICE);
/////////////////////////////
include("config.php");

function convertSchEcp2Date ($int) {
	#return $int;
	if (strlen($int)==0) return "-";
	return date("ymdHi", strtotime("20".substr($int, 0, 12)));
}

function validatePhoneNumber($num, $inter=false) {
	$thai_phone_digit = 9; // 864600000
	if ($inter) {
		if (strlen($num)<$thai_phone_digit+2) return false;
	}else{
		if (strlen($num)<$thai_phone_digit) return false;
		switch (strlen($num)) {
			case 9:
			break;
			case ($thai_phone_digit+1):
				if (substr($num,0,1)!="0") return false;
			break;
			case ($thai_phone_digit+2):
				if (substr($num,0,2)!="66") return false;
			break;
			default:
				return false;
			break;
		}
	}
	$phone_char = "+*#0123456789";
	for($i=0; $i<strlen($num); $i++) {
		if (strpos($phone_char,$num[$i]) === false) return false;
	}
	return true;
}
function convert2ThaiPhoneNumber($num, $format=2) {
	if (!validatePhoneNumber($num)) return false;
	switch($format) {
		case 0: // MDN
			return substr($num,-9);
		break;
		case 1: // Phone Number
			return "0".substr($num,-9);
		break;
		case 2: //SMSC, ISAG Format
			return "66".substr($num,-9);
		break;
		case 3: // Phone Number with country code
			return "+66".substr($num,-9);
		break;
	}
}

function validateNumber($num) {
	if (strlen($num)== 0) return false;
	$num_char = "0123456789";
	for($i=0; $i<strlen($num); $i++) {
		if (strpos($num_char,$num[$i]) === false) return false;
	}
	return true;
}

?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<!--
<style>
th {font-size:10px}
td {font-size:10px}
</style>
-->
<style type="text/css" title="currentStyle">
			

			@import "DataTable/css/demo_page.css";
			@import "DataTable/css/demo_table.css";
			@import "DataTable/css/jquery.dataTables.css";
			@import "DataTables-1.10.4/extensions/TableTools/css/dataTables.tableTools.css";

</style>

<script type="text/javascript" language="javascript" src="DataTable/js/jquery.js"></script>
<script type="text/javascript" language="javascript" src="DataTable/js/jquery.dataTables.js"></script>

<script type="text/javascript" charset="utf-8">
	$.fn.dataTableExt.oApi.fnGetHiddenTrNodes = function ( oSettings ){
		var anNodes = this.oApi._fnGetTrNodes( oSettings );
		var anDisplay = $('tbody tr', oSettings.nTable);
		for ( var i=0 ; i<anDisplay.length ; i++ ){
			var iIndex = jQuery.inArray( anDisplay[i], anNodes );
			if ( iIndex != -1 ){
				anNodes.splice( iIndex, 1 );
			}
		}
		return anNodes;
	}

var editor; // use a global for the submit and return data rendering in the examples
 
$(document).ready(function() {
    

	
	
		$('#example').dataTable( {
		"iDisplayLength": 25,
		"aLengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]] //แบ่งหน้า
			
      
		} );
    } );

</script>
<script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="js/jquery.dataTables.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.min.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.plus.min.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.picker.min.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.thai.min.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.thai-th.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.picker-th.js"></script>
<link type="text/css" href="jquery.calendars/humanity.calendars.picker.css" rel="stylesheet"/>

  <script>
  $(function() {
    
	$('#from_date').calendarsPicker({ minDate: "-3M -0D", maxDate:0, dateFormat:"yyyy-mm-dd", calendar: $.calendars.instance('thai','th')});
	$('#to_date').calendarsPicker({ minDate: "-3M -0D", maxDate:0, dateFormat:"yyyy-mm-dd", calendar: $.calendars.instance('thai','th')});
  });
 
  </script>

<?
$sql ="SELECT TOP 1 ReportUsage_Month FROM SBG_ReportUsage WHERE Customer_ID='".$_SESSION['Customer_ID']."' ORDER BY ReportUsage_Month DESC";
$mssql = mssql_query($sql);
list($Top_Month) = mssql_fetch_array($mssql);
//$Top_Month = "201302";
if(!empty($Top_Month)){
	$Current_Month = (int) substr($Top_Month,-2,2);
	$Current_Year = substr($Top_Month,0,4);
	if($Current_Month<6){
		$count_before=0;
		for($i=$Current_Month;$i>=1;$i--){
			$Array_MY[]=$Current_Year."0".$i;
			$count_before++;
		}
		$Next_Month = 12;
		$Next_Year = $Current_Year-1;
		$Next_MY = $Next_Year.$Next_Month;
		$Next_MY_Least = $Next_MY-(6-$count_before-1);
		for($i=$Next_MY;$i>=$Next_MY_Least;$i--){
			$Array_MY[]=$i;
		}
	}else{
		$Next_MY_Least = $Top_Month-6+1;
		for($i=$Top_Month;$i>=$Next_MY_Least;$i--){
			$Array_MY[]=$i;
		}
	}
}

?>


<table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
  <form action="<? $PHP_SELF?>" method="post" name="formCreateButton" id="formCreateButton">
    <tr>
      <td valign="top" class="tx_sub_head">The previous usage report 6 months</td>
    </tr>
  </form>
</table>
<br />
<table width="400" align="center" cellpadding="1" cellspacing="1" bgcolor="<?=$bg_tableBorder?>">
  <tr bgcolor="<?=$bg_tableHead?>">
    <td width="15%" align="center">No.</td>
    <td width="20%" align="center">Year</td>
    <td width="35%" height="25" align="center">Month</td>
    <td width="30%" align="center" height="25">Usage</td>
  </tr>
  <? 
  if(!empty($Top_Month)){
	  $no=1;
	  for($i=0;$i<count($Array_MY);$i++){
		  if($i%2==0){
			  $bg_table=$bg_tableEven;
		  }else{
			  $bg_table=$bg_tableOdd;
		  }
		  $value=0;
		  list($value)=mssql_fetch_array(mssql_query("SELECT ReportUsage_Amount FROM SBG_ReportUsage WHERE Customer_ID='".$_SESSION['Customer_ID']."' AND ReportUsage_Month='".$Array_MY[$i]."'"));
	  ?>
	  <tr bgcolor="<?=$bg_table?>">
		<td align="center"><?=$no;?></td>
		<td align="center"><?=substr($Array_MY[$i],0,4);?></td>
		<td align="center" height="25">
		<?
			$month_show = (int) substr($Array_MY[$i],-2,2);
			echo date("F", mktime(0, 0, 0, $month_show, 10));
		?></td>
		<td align="center" height="25"><?=number_format($value,0);?></td>
	  </tr>
	  <? 
	  $no++;}
  }else{?>
  <tr bgcolor="<?=$bg_tableEven?>">
    <td height="30" colspan="4" align="center">No data</td>
  </tr>
  <? } mssql_close;?>
</table>
<br /><br />


<?
$USER = $_SESSION["Customer_Account"];

$current_month=date('m');
$current_year=date('Y');

//get 2 months backward
if ($current_month =="01")
{
$previous1_month="12";
$previous1_year=$current_year-1;
$previous2_month="11";
$previous2_year=$current_year-1;
}
else if($current_month =="02")
{
$previous1_month="01";
$previous1_year=$current_year;
$previous2_month="12";
$previous2_year=$current_year-1;
}
else
{
$previous1_month=(strlen($current_month-1)==1)? "0".($current_month-1):$current_month-1;
$previous1_year=$current_year;
$previous2_month=(strlen($current_month-2)==1)? "0".($current_month-2):$current_month-2;
$previous2_year=$current_year;
}	
?>


<form name="form" action="<? $PHP_SELF?>" method="post">
    	<table width="400" align="center" cellpadding="1" cellspacing="1" bgcolor="<?=$bg_tableBorder?>">
		<tr>
    	<td align="center" class="tx_sub_head">Query TOP <select name="top" required><option>100</option><option>200</option><option>500</option><option>All</option></select></td></tr><tr><td>
        <table width="600" bgcolor="#FFFFFF">
			<tr>
        	  <td width="3%">&nbsp;</td>
        	  <td width="25%">&nbsp;</td>
        	  <td width="2%">&nbsp;</td>
        	  <td>&nbsp;</td>
     	    </tr>
			<!-- not need to set sender name
			<tr>
        	  <td height="25">&nbsp;</td>
        	  <td>Sender</td>
        	  <td>:</td>
        	  <td>
			  <?
				/*
				$dbname="VAS";
				$con=mssql_connect($dbhost,$dbuser,$dbpass) or die("CAN'T CONNECT DATABASE SERVER");
				mssql_select_db($dbname,$con) or die("CAN'T CONNECT DATABASE  $dbname ");
				*/
				$sqlSender="SELECT Sender_Name FROM SBG_Senders WHERE Customer_ID IN (SELECT Customer_ID FROM SBG_Customers WHERE Customer_ID='".$_SESSION['Customer_ID']."')";
				$querySender = mssql_query($sqlSender);
				$checkSender = mssql_num_rows($querySender);
				if($checkSender<>0){
				?>
				<select name="sms_msisdn_1" required>
				<? 
					if((strlen($USER)==10)&&(substr($USER,0,1)=="0")) echo "<option>$USER</option>";
					while($resultSender = mssql_fetch_array($querySender)){
				?>					
					<option value="<?php echo $resultSender['Sender_Name'];?>"><?php echo $resultSender['Sender_Name'];?></option>
				<?
					}
				?>
				</select>
				<?	
				}else{
				?>	
					<input name="sms_msisdn_1" type="text" size="20" maxlength="10" placeholder="Sender Name" required>
				<?
				}
			?>
			   </td>	
			</tr>-->
           	<tr>
        	  <td height="25">&nbsp;</td>
           	  <td>Receiver</td>
            	<td>:</td>
            	<td><input name="sms_msisdn_2" type="text" size="20" placeholder="Ex: 0XXXXXXXXX" value="<? if (strlen($_POST['sms_msisdn_2'])>0) echo $_POST['sms_msisdn_2'];?>"/></td>
            </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
           	  <td>Transaction ID</td>
              <td>:</td>
           	  <td><input name="transaction_id" type="text" size="47" /></td>
            </tr>
			<!--tr>
			  <td height="25">&nbsp;</td>
        	  <td>Month</td>
        	  <td>:</td>
			  <td>
			  <select name="month">	
				<option value="<?php echo $current_month;?>"><?php echo $current_month;?></option>
				<option value="<?php echo $previous1_month;?>"><?php echo $previous1_month;?></option>
				<option value="<?php echo $previous2_month;?>"><?php echo $previous2_month;?></option>				
			  </select>
			  </td>
			</tr-->
        	<tr>
				<td height="25">&nbsp;</td>
				<td>From (Date Time)</td>
				<td>:</td>
				<td><input name="from_date" type="text" id="from_date" value="<? if ($_POST['from_date']) echo $_POST['from_date']; else echo date("Y-m-d", strtotime("-1day"))?>" required>*&nbsp;&nbsp;&nbsp;<input name="from_time" type="text" id="from_time" placeholder="00:00:00" maxlength="8" size="8" value="<?  if ($_POST['from_time']) echo $_POST['from_time'];?>">&nbsp;Ex: HH:MM:SS</td>
			</tr>
			<tr>
				<td height="25">&nbsp;</td>
				<td>To (Date Time)</td>
				<td>:</td>
				<td><input name="to_date" type="text" id="to_date" value="<? if ($_POST['to_date']) echo $_POST['to_date']; else echo date("Y-m-d")?>" required>*&nbsp;&nbsp;&nbsp;<input name="to_time" type="text" id="to_time" placeholder="23:59:59" maxlength="8" size="8" value="<?  if ($_POST['to_time']) echo $_POST['to_time'];?>">&nbsp;Ex: HH:MM:SS</td>
			</tr>
		  	<tr>
        	  <td height="50" colspan="4" align="center">
			  <input type="hidden" name="method" value="query" />
			  <input type="submit" name="query" value="Query" />
       	      &nbsp;
       	      <input type="reset" name="Reset" id="button" value="Reset" /></td>
       	    </tr>
 </table>
        </td></tr></table>
        </form>
		
<br><br>
 
 <?
 
 /*
	if(empty($_POST['query'])){
 echo "<br><center>No Report</center>";
 }else{
			
		$sender=$_POST['sms_msisdn_1'];
		$receiver=$_POST['sms_msisdn_2'];
		$transaction_id=$_POST['transaction_id'];

		$a=array($_POST['sms_msisdn_1'],$_POST['sms_msisdn_2'],$_POST['transaction_id']);
 
  if((empty($a[0]))&&(empty($a[1]))&&(empty($a[2])))
 {
	echo "<br><center>Please fill data</center>";
 }else{
 $AND1=" AND originate_number = '".$sender."'";
 $AND2=" AND terminate_number = '".$receiver."'";
 $AND3=" AND transaction_id = '".$transaction_id."'";
 
 $b=array($AND1,$AND2,$AND3);


 for($i=0;$i<=2;$i++)
 {
	if(!empty($a[$i]))
	{
		$tmp=$tmp.$b[$i];
		
	}	
	 
 }
 //*/
 
 
if(empty($_POST['query'])){
 echo "<br><center>No Report</center>";
 }else{
	 
	 if((empty($_POST['from_date']))||(empty($_POST['from_date'])))
 {
	echo "<br><center>Please fill data</center>";
 }else{
	 $tmp = "";
 if (strlen($_POST['sms_msisdn_2'])>0) $tmp .=" AND terminate_number = '".convert2ThaiPhoneNumber($_POST['sms_msisdn_2'])."'";
 if (strlen($_POST['transaction_id'])>0) $tmp .=" AND transaction_id = '".$_POST['transaction_id']."'";
 //*/
 
if (strlen($_POST['from_time'])==0) $_POST['from_time'] = "00:00:00.000";
if (strlen($_POST['to_time'])==0) $_POST['to_time'] = "23:59:59.999"; 
$from=$_POST['from_date']." ".$_POST['from_time'].".000";
$to=$_POST['to_date']." ".$_POST['to_time'].".999";
if($_POST['top']=="All"){
	$top="";
}else{
	$top="TOP ".$_POST['top'];
}
$dbname="SMS";
$con=mssql_connect($dbhost,$dbuser,$dbpass) or die("CAN'T CONNECT DATABASE SERVER");
mssql_select_db($dbname,$con) or die("CAN'T CONNECT DATABASE  $dbname ");

$sql1="SELECT ".$top." transaction_id,originate_number,terminate_number,message,scheduled,validity,current_message,summary_message,sm_id,error_code,deliver_code,CONVERT(VARCHAR(20), incoming_datetime, 111) + ' ' + CONVERT(VARCHAR(8),incoming_datetime, 108) as incoming_datetime,CONVERT(VARCHAR(20), responding_datetime, 111) + ' ' + CONVERT(VARCHAR(8),responding_datetime, 108) as responding_datetime,CONVERT(VARCHAR(20), deliver_datetime, 111) + ' ' + CONVERT(VARCHAR(8),deliver_datetime, 108) as deliver_datetime FROM SMSCDR".$current_month." WHERE charge_account = '$USER' AND (service_type = 'SBG' OR service_type = 'BUK') ".$tmp." AND CONVERT(VARCHAR(20), responding_datetime, 120) + ' ' + CONVERT(VARCHAR(8),responding_datetime, 108) BETWEEN '$from' AND '$to'";
$sql1.=" UNION SELECT ".$top." transaction_id,originate_number,terminate_number,message,scheduled,validity,current_message,summary_message,sm_id,error_code,deliver_code,CONVERT(VARCHAR(20), incoming_datetime, 111) + ' ' + CONVERT(VARCHAR(8),incoming_datetime, 108) as incoming_datetime,CONVERT(VARCHAR(20), responding_datetime, 111) + ' ' + CONVERT(VARCHAR(8),responding_datetime, 108) as responding_datetime,CONVERT(VARCHAR(20), deliver_datetime, 111) + ' ' + CONVERT(VARCHAR(8),deliver_datetime, 108) as deliver_datetime FROM SMSCDR".$previous1_month." WHERE charge_account = '$USER' AND (service_type = 'SBG' OR service_type = 'BUK') ".$tmp." AND CONVERT(VARCHAR(20), responding_datetime, 120) + ' ' + CONVERT(VARCHAR(8),responding_datetime, 108) BETWEEN '$from' AND '$to'";
$sql1.=" UNION SELECT ".$top." transaction_id,originate_number,terminate_number,message,scheduled,validity,current_message,summary_message,sm_id,error_code,deliver_code,CONVERT(VARCHAR(20), incoming_datetime, 111) + ' ' + CONVERT(VARCHAR(8),incoming_datetime, 108) as incoming_datetime,CONVERT(VARCHAR(20), responding_datetime, 111) + ' ' + CONVERT(VARCHAR(8),responding_datetime, 108) as responding_datetime,CONVERT(VARCHAR(20), deliver_datetime, 111) + ' ' + CONVERT(VARCHAR(8),deliver_datetime, 108) as deliver_datetime FROM SMSCDR".$previous2_month." WHERE charge_account = '$USER' AND (service_type = 'SBG' OR service_type = 'BUK') ".$tmp." AND CONVERT(VARCHAR(20), responding_datetime, 120) + ' ' + CONVERT(VARCHAR(8),responding_datetime, 108) BETWEEN '$from' AND '$to' ORDER BY incoming_datetime DESC";
//echo $sql1;
}
	
 
 ?>
 
 <div id="container">
			<div class="full_width big"></div>
 
<table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
  <form action="<? $PHP_SELF?>" method="post" name="formCreateButton" id="formCreateButton">
    <tr>
      <td valign="top" class="tx_sub_head">The previous report details 3 months</td>
    </tr>
  </form>
</table>
<br>		 
<table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">

	  <tr>
		<td colspan="2"><div id="demo">
            <table cellpadding="0" cellspacing="0" border="0" class="display" id="example">
	<thead>
		<tr>
			<th>Transaction ID<BR/>incoming<BR/>response<BR/>delivery<!--<BR/>sm_id--></th>
			<th>Sender<BR/>Receiver</th>
              <!--<th>Receiver</th>-->
			<th>Message</th>
			<th>Schedule<BR/>Expire</th>
			<th>Cur / Sum</th>
			<th>SMS ID</th>
			<th>Error Code<BR/>Deliver Code</th>
			<!--<th>Deliver Code--></th>
			<!--<th></th>-->
		</tr>
	</thead>

	<tbody>
<?
$query1 = mssql_query($sql1) or die ("sql error [".$sql1."]"); //0830766059
   while($row1 = mssql_fetch_array($query1)){
	if(strlen($row1['message'])>70){
		$message=substr($row1['message'],0,70)."...";
	}else{
		$message=$row1['message'];
	}	
   ?>

	<tr class="odd_gradeX">
 	    <td><?php echo $row1['transaction_id'];?><BR/>inco:<? echo substr($row1['incoming_datetime'],0,19);?><BR/>resp:<?=substr($row1['responding_datetime'],0,19);?><BR/>deli:<?=substr($row1['deliver_datetime'],0,19);?><!--<BR/>smid:<?php echo $row1['sm_id'];?>--></td>
		<td>Sen:<?php echo $row1['originate_number'];?><BR/>Rec:<?php echo convert2ThaiPhoneNumber($row1['terminate_number'], 1);?></td>
		<!--<td><?php echo $row1['terminate_number'];?></td>-->
		<td title="<?=$row1['message']?>"><?php echo $message;?></td>
		<td>Sch:<?php echo convertSchEcp2Date($row1['scheduled']);?><br>Exp:<?php echo convertSchEcp2Date($row1['validity']);?></td>
		<td><center><?php echo $row1['current_message']."/".$row1['summary_message'];?></center></td>
		<td><center><?php echo $row1['sm_id'];?></center></td>
		<td><center><?php echo $row1['error_code'];?><BR/><?php echo $row1['deliver_code'];?></center></td>
		<!--<td><center><?php echo $row1['deliver_code'];?></center></td>-->
		<!--<td></td> เปลี่ยนจาก10เป็น11 เพราะตัดหลังอักษรที่11 เช่น... 31 Oct 2014-->
       <!--เปลี่ยนจาก10เป็น11 เพราะตัดหลังอักษรที่11 เช่น... 31 Oct 2014-->
	</tr>
	
<?php } ?>	
	</tbody>

</table>
		  </div>
			<div class="spacer"><BR/><BR/>
				Error Code detail<BR/>
				0 = No error<BR/>
				97 = Invalid time format<BR/>
				98 = Invalid expire format<BR/>
				1041 = Maximum submission exceeded<BR/>
				1042 = Over quota limit<BR/>
				1078 = Invalid destination<BR/>
				1375 = SLA service level agreement in UAG
			</div>
			<div class="spacer"><BR/>
				Deliver Code detail<BR/>
				0 = [DELIVERED] Success/Message is delivered to destination<BR/>
				161 = [EXPIRED] Message validity period has expired<BR/>
				162 = [DELETED] Message has been deleted<BR/>
				163 = [UNDELIV] Message is undeliverable<BR/>
				164 = [ACCEPTD] Message is in accepted state<BR/>
				165 = [UNKNOWN] Message is in invalid state<BR/>
				166 = [REJECTD] Message is in a rejected state<BR/>
				167 = [ENROUTE] The message is in enroute state
			</div>
</table>
 
			<h1>&nbsp;</h1>
		</div>
	<?}?>

