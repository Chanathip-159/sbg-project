<html>
<body>
<?php

include("config.php");//ติดต่อฐานข้อมูล

$username=$_REQUEST['username'];

$sql_check="SELECT COUNT(username) AS cuser FROM tb_user WHERE username='$username'";//นับจำนวน username

$query_check=mysql_query($sql_check);

$result_check=mysql_fetch_array($query_check);

echo $result_check['cuser'];//แสดงจำนวนที่พบ

?>
<input type="text" name="username" id="username" onblur="check_username(this.value)"/>
<span id="err_user_same" class="spanerr" style="display:none"> username is already in use.
</span>
<script>

function check_username(username){

HttPRequest = false;

if (window.XMLHttpRequest) { // Mozilla, Safari,...

HttPRequest = new XMLHttpRequest();

 if (HttPRequest.overrideMimeType) {

 HttPRequest.overrideMimeType('text/html');

 }

} else if (window.ActiveXObject) { // IE

 try {

 HttPRequest = new ActiveXObject("Msxml2.XMLHTTP");

 } catch (e) {

  try {

  HttPRequest = new ActiveXObject("Microsoft.XMLHTTP");

  } catch (e) {}

 }

}

if (!HttPRequest) {

alert('Cannot create XMLHTTP instance');

return false;

}

var url = 'source.php';

var pmeters ="username="+username;

HttPRequest.open('POST',url,true);

HttPRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

HttPRequest.setRequestHeader("Content-length", pmeters.length);

HttPRequest.setRequestHeader("Connection", "close");

if(username!=""){

HttPRequest.send(pmeters);

}else{

document.getElementById("username").className=""

document.getElementById("err_user_same").style.display="none"

}

 HttPRequest.onreadystatechange = function(){

  if(HttPRequest.readyState == 4) // Return Request

  {

   if(HttPRequest.responseText==0){

    document.getElementById("username").className=""

    document.getElementById("err_user_same").style.display="none"

   }else{

    document.getElementById("username").focus()

    document.getElementById("username").className="errtext"

    document.getElementById("err_user_same").style.display=""

   }

  }

 }

}

</script>


</body>
</html>