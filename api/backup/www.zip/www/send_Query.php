<?
session_start();
include("config.php");
define('__max_rows__',"100");
/*
$user="<YOUR USERNAME>";
$pass="<YOUR PASSWORD>";
$from="Sendername";
$target="66864600000,668646000001"; // 66864600000,668646000001

$user="0864601062";
$pass="1062";
$from="Sendername";
$target="66864601062"; // 66864600000,668646000001

$mess = iconv("windows-874","UTF-8","");
$mess = urlencode($mess);
$lang="T";

//*/
//print_r(array_filter($_POST['Receiver']));
//print_r($_POST['Receiver']);
include_once("api/bulk.api.engine.php");

$sql = "SELECT [Customer_Account],[Customer_Password] 
	FROM [VAS].[dbo].[SBG_Customers] 
	WHERE [Customer_ID] = '".$_SESSION['Customer_ID']."';";
$mssql = mssql_query($sql);
$account=mssql_fetch_array($mssql);

//print_r($_POST);

if($_POST['Expire_Type']=="add"){
	$ExpireTime= date("Y-m-d H:i:s", strtotime(date("Y-m-d H:i:s") . " +".$_POST['Expire_HourCount']." hours"));
}else if($_POST['Expire_Type']=="set"){
	$ExpireTime = $_POST['Expire_Date']." ".$_POST['Expire_Hour'].":".$_POST['Expire_Minute'].":00";
}

if ($_POST['SendMode']=="Manual") {
	echo sendSMSEngine(
		$account['Customer_Account']
		, $account['Customer_Password']
		, $_POST['Sender_Name']
		, implode(',',array_filter($_POST['Receiver']))
		, $_POST['MsgTxt']
		, $_POST['LangType']
		, $ExpireTime
	);
}elseif ($_POST['SendMode']=="Group") {
	//echo print_r($_POST);
	if (empty($_POST['Group_Path'])) { // system
		$sql = "SELECT [Number_No] FROM [VAS].[dbo].[SBG_Numberings] WHERE [Group_ID] = '".$_POST['Group_ID']."';";
		$mssql = mssql_query($sql);
		while($data = mssql_fetch_array($mssql)) $msisdn[] = $data['Number_No'];
		$msisdn_div = array_chunk($msisdn, __max_rows__);
		$result = Array();
		foreach ($msisdn_div AS $msisdn_group) {
			$result[] = sendSMSEngine(
				$account['Customer_Account']
				, $account['Customer_Password']
				, $_POST['Sender_Name']
				, implode(',',array_filter($msisdn_group))
				, $_POST['MsgTxt']
				, $_POST['LangType']
				, $ExpireTime
			);
		}
		//sleep(5);
		echo "Success!<br>".implode('\n', $result);
	}else{ // file
		$msisdn = explode("\n",str_replace("\r","",file_get_contents($_POST['Group_Path'])));
		$msisdn_div = array_chunk(array_filter($msisdn), __max_rows__);
		$result = Array();
		foreach ($msisdn_div AS $msisdn_group) {
			$result[] = sendSMSEngine(
				$account['Customer_Account']
				, $account['Customer_Password']
				, $_POST['Sender_Name']
				, implode(',',array_filter($msisdn_group))
				, $_POST['MsgTxt']
				, $_POST['LangType']
			);
		}
		//sleep(5);
		echo "Success!<br>".implode('\n', $result);
		
	}
	
}
?>