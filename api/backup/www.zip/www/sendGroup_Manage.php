<? 
include("config.php");

if (empty($_POST['Group_ID'])) {
	?>
<SCRIPT language="JavaScript">
alert("Can not get Group ID."); 
window.history.back();
</SCRIPT> 
    <?
}
$Group_ID=$_POST['Group_ID'];
$Group_Method=$_POST['Group_Method'];
$Group_Title=$_POST['Group_Title'];
if(!empty($_POST['Group_TotalFileNumbering'])){
	$total=$_POST['Group_TotalFileNumbering'];
}else{
	$total=$_POST['Group_TotalNumber'];
}
if(empty($_POST['Group_Path'])){
	$Group_Path="";
}else{
	$Group_Path=$_POST['Group_Path'];
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" language="javascript" src="DataTable/js/jquery.js"></script>
<script src="./js/jquery-2.1.4.min.js"></script>
	<script src="./js/pace.js"></script>
	<link href="./js/pace-theme-barber-shop.css" rel="stylesheet" />
    <script>
      $(function () {

        $('form').on('submit', function (e) {
		  $('#sub').attr('disabled','disabled');
          e.preventDefault();

		  	Pace.track(function(){
          $.ajax({
            type: 'post',
            url: 'send_Query.php',
            data: $('form').serialize(),
            success: function (result) {
              $('#message').html(result);
			  $('#sub').removeAttr('disabled');
            }
          });
			});
        });

      });
	</script>
<script language="javascript">
function ProcessSMS() {
	var txt = document.getElementById("MsgTxt").value;
	if (checkThai()) { // check thai
		document.getElementById("Counter_SMS").value = Math.ceil(txt.length/140);
	}else{
		document.getElementById("Counter_SMS").value = Math.ceil(txt.length/70);
	}
} 
function checkThai() {
	var txt = document.getElementById("MsgTxt").value;
	for(var i = 0;i < txt.length; i++) {
		if( (txt.charCodeAt(i) > 127) || (txt.charCodeAt(i)==94) || (txt.charCodeAt(i)==92) ) { 
			document.getElementById("LangType").value = "T";
			return false;
		}
	}
	document.getElementById("LangType").value = "E";
	return true;
}
function validateTime(){
	
    var today = new Date();
    var yyyy = today.getFullYear();
    var mm = today.getMonth()+1;
    var dd = today.getDate();
	var hrs = today.getHours();
	var mns = today.getMinutes();
    if(dd<10) dd = '0' + dd;
    if(mm<10) mm = '0' + mm;
    if(mns<10) mns = '0' + mns;
    today = yyyy + '-' + mm + '-' + dd;
	var startDate = today + ' ' + hrs + ':' + mns + ':00';
	
	/*if(document.getElementById("Expire_TypeSet").checked){
		
		var time = document.getElementById("Expire_Time").value;
		var newreg =  /^(([0-1][0-9])|(2[0-3])):[0-5][0-9]$/;
		
		if(!newreg.test(time)){
			
			alert("Invalid time format\n The valid format is hh:mm\n");
			return false;
			
		}else{
			
			var endDate = today + ' ' + time + ':00';
			
			var startDateConvert = new Date(parseInt(startDate.substr(0,4)),parseInt(startDate.substr(5,2)),parseInt(startDate.substr(8,2)),parseInt(startDate.substr(11,2)),parseInt(startDate.substr(14,2)),0);
			var endDateConvert = new Date(parseInt(endDate.substr(0,4)),parseInt(endDate.substr(5,2)),parseInt(endDate.substr(8,2)),parseInt(endDate.substr(11,2)),parseInt(endDate.substr(14,2)),0);
			
			var difference = (endDateConvert.getTime() - startDateConvert.getTime())/60000;
			
			if(difference<5){
				alert('Expire time must more than Current time at least five minutes.');
				return false;
			}			
		}
		
	}else */
	if(document.getElementById("Expire_TypeQuarter").checked){
		
		var endDate = document.getElementById("Expire_Date").value + ' ' + document.getElementById("Expire_Hour").value + ':' + document.getElementById("Expire_Minute").value + ':00';
		
		var startDateConvert = new Date(parseInt(startDate.substr(0,4)),parseInt(startDate.substr(5,2)),parseInt(startDate.substr(8,2)),parseInt(startDate.substr(11,2)),parseInt(startDate.substr(14,2)),0);
		var endDateConvert = new Date(parseInt(endDate.substr(0,4)),parseInt(endDate.substr(5,2)),parseInt(endDate.substr(8,2)),parseInt(endDate.substr(11,2)),parseInt(endDate.substr(14,2)),0);
		
		var difference = (endDateConvert.getTime() - startDateConvert.getTime())/60000;
		if(difference<5){
			alert('Expire time must more than Current time at least five minutes.');
			return false;	
		}	
		
	}
	return true;
}
function settime() {
   document.getElementById("expireTime").style.display = '';
   document.getElementById("expireDate").style.display = 'none';
}
function choosetime() {
   document.getElementById("expireTime").style.display = 'none';
   document.getElementById("expireDate").style.display = '';
}
</script>
<table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td valign="top" class="tx_sub_head">Send SMS to <?=$Group_Title?> Group</td>
  </tr>
</table><br />

<form name = "sender" id="sender" action = "send_Query.php" method = "POST" onsubmit="return validateTime();">
  <table cellpadding="1" cellspacing="1" bgcolor="<?=$bg_form?>" align="center">
    <tr>
    <td align="center" class="tx_sub_head">Send SMS From</td>
  </tr>
  <tr>
    <td><table width="500" bgcolor="#FFFFFF" align="center">
      <tr>
        <td width="3%">&nbsp;</td>
        <td width="30%">&nbsp;</td>
        <td width="2%">&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td height="25">&nbsp;</td>
        <td>Sender Name</td>
        <td>:</td>
        <?
		$sql_msisdn = "SELECT [Customer_Account] FROM [VAS].[dbo].[SBG_Customers] WHERE [Customer_ID] = '".$_SESSION["Customer_ID"]."';";
		$mssql_msisdn = mssql_query($sql_msisdn);
		$objResult_msisdn = mssql_fetch_array($mssql_msisdn);
		$msisdn = $objResult_msisdn['Customer_Account'];
		
		if((strlen($msisdn)==10)&&(substr($msisdn,0,1)=="0")){
			?><td><select name="Sender_Name" ><option><?=$msisdn?></option><?
		}else{
			?><td><select name="Sender_Name" ><?
		}
		$sql = "SELECT [Sender_Name] FROM [VAS].[dbo].[SBG_Senders] WHERE [Customer_ID] = '".$_SESSION["Customer_ID"]."';";
		$mssql = mssql_query($sql);
		$haveRow = false;
		while($data = mssql_fetch_array($mssql)) {
			$haveRow = true;
			$senders[] = $data['Sender_Name'];
		}
		if ($haveRow) {
		?>
			<? foreach($senders AS $sender) {?><option><?=$sender?></option><? }?></select></td>
        <?
		} else {
			/*?><option><?=$msisdn?></option></select></td><?*/
			if((strlen($msisdn)==10)&&(substr($msisdn,0,1)=="0")){
				?></select></td><?
			}else{
				?><option><?=$msisdn?></option></select></td><?
			}
		}			
		?>
      </tr>
      <tr>
        <td height="25">&nbsp;</td>
        <td>Group Receiver</td>
        <td>:</td>
        <td><?=$Group_Title?></td>
      </tr>
      <tr>
        <td height="25">&nbsp;</td>
        <td>Total of numbering</td>
        <td>:</td>
        <td><?=$total?> Numberings</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td valign="top">Expire type</td>
        <td valign="top">:</td>
        <td valign="top">
        <input name="Expire_Type" id="Expire_TypeSet" type="radio" value="add" onClick="settime();" />
        + Hours (Maximum +24 hrs.)<br />
        <input name="Expire_Type" id="Expire_TypeQuarter" type="radio" value="set" onClick="choosetime();" />
        Set time (Within midnight)</td>
        </tr>
      <tr height="35" id="expireTime" style="display:none;">
        <td>&nbsp;</td>
        <td>Expire date</td>
        <td>:</td>
        <td>
        <select name="Expire_HourCount" id="Expire_HourCount">
        <? for($i=1;$i<=24;$i++){?>
        <option value="<?=$i?>">+ <?=$i?> hrs.</option>
        <? }?>
        </select>
        <!--<input name="Expire_Time" id="Expire_Time" type="text" size="10" placeholder="23:59" on /> [Format 23:59]--></td>
        </tr>
      <tr height="35" id="expireDate" style="display:none;">
        <td>&nbsp;</td>
        <td>Expire date</td>
        <td>:</td>
        <td>
        <?
		$current_date = date("Y-m-d");
		$current_hour = date("H");
		$count_hour = 0;
		?>
        <input type="text" name="Expire_Date" id="Expire_Date" readonly="readonly" value="<?=$current_date?>" size="7" />
        <select name="Expire_Hour" id="Expire_Hour">
        <? 
		for($i=$current_hour;$i<=23;$i++){
			if(strlen($i)==1){$hour="0".$i;}else{$hour=$i;}
			?>
			<option><?=$hour?></option>
			<? 
			$count_hour++;
		}
		/*
		if($count_hour<24){
			$last_hour = 23-$count_hour;
			$current_date = date("Y-m-d");
			$tomorrow_date = date('Y-m-d',strtotime($current_date . "+1 days"));
			for($i=0;$i<=$last_hour;$i++){
				if(strlen($i)==1){$hour="0".$i;}else{$hour=$i;}
				?>
				<option><?=$tomorrow_date."&nbsp;".$hour?></option>
				<? 
			}
		}*/
		?>
        </select>&nbsp;:&nbsp;
        <select name="Expire_Minute" id="Expire_Minute">
        <? for($i=0;$i<=59;$i++){if(strlen($i)==1){$minute="0".$i;}else{$minute=$i;}?>
        <option value="<?=$minute?>"><?=$minute?></option>
        <? }?>
        </select>
        </td>
        </tr>
      <tr>
        <td height="25" valign="top">&nbsp;</td>
        <td valign="top">Message</td>
        <td valign="top">:</td>
        <td><textarea name="MsgTxt" id="MsgTxt" cols="40" rows="5" onKeyUp="ProcessSMS();"></textarea></td>
      </tr>
      <tr>
        <td height="25">&nbsp;</td>
        <td>Number of message</td>
        <td>:</td>
        <td><input name="Counter_SMS" id="Counter_SMS" type="text" size="10" /></td>
      </tr>
      <tr>
        <td height="50" colspan="4" align="center">
        	<input name="SendMode" id="SendMode" type="hidden" value="Group" />
            <input name="Group_ID" id="Group_ID" type="hidden" value="<?=$Group_ID?>"/>
            <? if($Group_Method=="F"){?>
            <input name="Group_Path" id="Group_Path" type="hidden" value="<?=$Group_Path?>"/>
            <? }?>
            <input name="LangType" id="LangType" type="hidden" />
            <input type="submit" id="sub" name="Submit" value="Send" OnClick="return alert('SMS Delivery may take long time. Please wait.');" />
         </td>
      </tr>
    </table></td>
  </tr>
</table>
</form>

<br /><br /><center><p id="message"></p></center>
<!--
<script language="javascript">
$("form#sender").submit(function(e){
	//var formData = new FormData($(this)[0]);
	$('#sub').attr('disabled','disabled');
          e.preventDefault();

		  	Pace.track(function(){
    $.ajax({
        url: $(this).attr('action'), //$(this).attr('action'),
        type: $(this).attr('method'), //$(this).attr('method'),
        //data: formData,
		data: $("form#sender").serialize(),
        async: false,
        crossDomain: true,
        /*
		success: function (data) {
            alert(data); //alert(data); document.write(data);
        },
		*/
		success: function (result) {
            $('#message').html(result);
			$('#sub').removeAttr('disabled');
        }
        cache: false,
        contentType: false,
        processData: false
    });
    return false; //STOP default action
})
})


;
</script>
-->
</body>
</html>