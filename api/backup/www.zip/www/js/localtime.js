var dp_cal;      
window.onload = function () {
  dp_cal  = new Epoch('epoch_popup','popup',document.getElementById('popup_container'));
  };
  <!--
  function MM_jumpMenu(targ,selObj,restore){ //v3.0
	  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
	  if (restore) selObj.selectedIndex=0;
  }
  function date_time(id)
  {
		  date = new Date;
		  year = date.getFullYear();
		  year = year+543;
		  year_ = year.toString();
		  month = date.getMonth();
		  months = new Array('ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.');
		  d = date.getDate();
		  day = date.getDay();
		  days = new Array('อาทิตย์', 'จันทร์', 'อังคาร', 'พุธ', 'พฤหัสบดี', 'ศุกร์', 'เสาร์');
		  h = date.getHours();
		  if(h<10)
		  {
				  h = "0"+h;
		  }
		  m = date.getMinutes();
		  if(m<10)
		  {
				  m = "0"+m;
		  }
		  s = date.getSeconds();
		  if(s<10)
		  {
				  s = "0"+s;
		  }
		  result = 'วัน'+days[day]+'ที่ '+d+' '+months[month]+' '+year_.substr(2,2)+' '+h+':'+m+':'+s+'&nbsp;';
		  document.getElementById(id).innerHTML = result;
		  setTimeout('date_time("'+id+'");','1000');
		  return true;
  }
  //-->