<!--<script type="text/javascript" src="js/localtime.js"></script>-->
<table width="100%" cellpadding="0" cellspacing="0" bgcolor="<?=$bg_menu?>">
  <tr>
    <td class="tx_sub_head">&nbsp;<!--<script type="text/javascript">date_time('date_time');</script>--></td>
  <? if(!empty($_SESSION['Admin_ID'])){?>
    <td width="10%" align="center" class="tx_sub_head" <? if($pg=="customer"){echo "bgcolor=#F9F9F9";}?>><a href="index.php?pg=customer">Customers</a></td>
    <td width="10%" align="center" class="tx_sub_head" <? if($pg=="user"){echo "bgcolor=#F9F9F9";}?>><a href="index.php?pg=user">Admins.</a></td>
    <td width="13%" align="center" class="tx_sub_head" <? if($pg=="restart"){echo "bgcolor=#F9F9F9";}?>><a href="index.php?pg=restart">Restart Service</a></td>
    <td width="8%" align="center" class="tx_sub_head" <? if($pg=="traffic"){echo "bgcolor=#F9F9F9";}?>><a href="index.php?pg=traffic">Traffic</a></td>
  <? }else if(!empty($_SESSION['Customer_ID'])){?>
    <td width="8%" align="center" class="tx_sub_head" <? if($pg=="group"||$pg=="number"){echo "bgcolor=#F9F9F9";}?>><a href="index.php?pg=group">Groups</a></td>
    <td width="11%" align="center" class="tx_sub_head" <? if($pg=="sendManual"){echo "bgcolor=#F9F9F9";}?>><a href="index.php?pg=sendManual">Send Manual</a></td>
    <td width="8%" align="center" class="tx_sub_head" <? if($pg=="report"){echo "bgcolor=#F9F9F9";}?>><a href="index.php?pg=report">Report</a></td>
  <? }?>
    <td width="8%" align="center" class="tx_sub_head" <? if($pg=="profile"){echo "bgcolor=#F9F9F9";}?>><a href="index.php?pg=profile">Profile</a></td>
    <td width="13%" align="center" class="tx_sub_head" <? if($pg=="change"){echo "bgcolor=#F9F9F9";}?>><a href="index.php?pg=change">Change Password</a></td>
    <td width="8%" align="center" class="tx_sub_head"><a href="index.php?logout=logout">Logout</a></td>
  </tr>
</table>