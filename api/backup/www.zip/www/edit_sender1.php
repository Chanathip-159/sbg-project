<?
//have problem in line: 21 and 56, "sender name".
//ob_start();
session_start();
include("config.php");
include("fn/fn.php");
///////////////////////////// show errors
ini_set('display_errors', 1); 
error_reporting(E_ALL);
/////////////////////////////

$Customer_ID = $_GET['id'];
echo $Customer_ID;

//$sql ="SELECT * FROM SBG_Senders WHERE Customer_ID='".$_GET['id']."'";
//$mssql = mssql_query($sql);
//if(empty($_POST['edit_sender'])){
	//$sql_1=mssql_query("SELECT * From SBG_Senders where Customer_ID ='".$_GET['id']."'");
	$sql_1=mssql_query("SELECT * From SBG_Senders where Customer_ID = 26");
	//$sql_2=mssql_query("SELECT * From SBG_Senders where Customer_ID ='".$_POST['Request_ID']."'");
	$edit_sender1=mssql_fetch_array($sql_1);
		
	echo $edit_sender1['Sender_Name'];
	

?>
