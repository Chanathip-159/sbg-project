<?
session_start();
include("config.php");
include("fn/fn.php");
///////////////////////////// show errors
ini_set('display_errors', 1); 
error_reporting(E_ALL);
/////////////////////////////
$checkError = ini_get('error_reporting');
error_reporting($checkError  ^ E_NOTICE);
/////////////////////////////
?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
<link href="css/style.css" rel="stylesheet" type="text/css">
<?
$date_now=Date("Y-m-j H:i:s");
if(!empty($_SESSION['Customer_ID'])){ //Check Session
	if($_POST['method']=="create"&&$_SESSION['Customer_ID']&&$_POST['Rows']<100){ //Method
		$sql = "SELECT Group_Title FROM SBG_Groups WHERE Group_Title='".$_POST['Group_Title']."' AND Customer_ID='".$_SESSION['Customer_ID']."'";
		$mssql = mssql_query($sql);
		$check_duplicate = mssql_num_rows($mssql);
		if($check_duplicate==0){
			$count_numbering = 0;
			$sql="INSERT INTO SBG_Groups
				   ([Group_Method]
				   ,[Group_Title]
				   ,[Group_TotalFileNumbering]
				   ,[Group_Description]
				   ,[Group_CreateDate]
				   ,[Customer_ID])
				VALUES
				   ('".$_POST['Group_Method']."'
				   ,'".$_POST['Group_Title']."'
				   ,'".$count_numbering."'
				   ,'".$_POST['Group_Description']."'
				   ,'".$date_now."'
				   ,'".$_SESSION['Customer_ID']."')";
			mssql_query($sql);
			if(!empty($_FILES["file"]["type"])){
				list($Current_Group_ID) = mssql_fetch_array(mssql_query("SELECT MAX(Group_ID) FROM SBG_Groups"));
				$file_name = "files/".md5($_SESSION['Customer_ID']."_".$Current_Group_ID).strrchr($_FILES["file"]["name"],".");
				move_uploaded_file($_FILES["file"]["tmp_name"],$file_name);
				$objFopen = fopen($file_name, 'r');
				if ($objFopen) {
					 $context = file_get_contents($file_name); $error="";
					 $context_get = explode("\n",str_replace("\r","",$context));
					 $context_filter = array_filter($context_get);
					 for($i=0;$i<count($context_filter);$i++){
						 if(!preg_match("/^0[0-9]{9}$/", $context_filter[$i])) {
							unlink($file_name);
							mssql_query("DELECT FROM SBG_Groups WHERE Group_ID='".$Current_Group_ID."'");
							$ext="pg-group";
							header("refresh: 0; url=result.php?nextPage=index&ext=$ext&status=incorrect");
						 }
						 $count_numbering++;
					 }
					 mssql_query("UPDATE SBG_Groups SET Group_TotalFileNumbering='".$count_numbering."' WHERE Group_ID='".$Current_Group_ID."'");
				}
			}
			$ext="pg-group";
			header("refresh: 0; url=result.php?nextPage=index&ext=$ext");
		}else{
			$ext="pg-group";
			header("refresh: 0; url=result.php?nextPage=index&ext=$ext&status=repeat");
		}
	}else if($_POST['method']=="edit"&&$_POST['Group_Title']){
		$count_numbering = 0;
		$complete = true;
		$status="";
		if(!empty($_FILES["file"]["type"])){
			$file_name = "files/".md5($_SESSION['Customer_ID']."_".$_POST['Group_ID']).".txt";
			$file_temp = "files/data.txt";
			move_uploaded_file($_FILES["file"]["tmp_name"],$file_temp);
			$objFopen = fopen($file_temp, 'r');
			if ($objFopen) {
				 $context = file_get_contents($file_temp); $error="";
				 $context_get = explode("\n",str_replace("\r","",$context));
				 $context_filter = array_filter($context_get);
				 for($i=0;$i<count($context_filter);$i++){
					 if(!preg_match("/^0[0-9]{9}$/", $context_filter[$i])) {
						 $complete = false;
					 }
					 if($complete){
						 $count_numbering++;
					 }
				 }
				 if($complete){
					 if(file_exists($file_name)){
						 unlink($file_name);
					 }
					 rename($file_temp, $file_name);
				 }else{
					 unlink($file_temp);
					 $ext="pg-group";
					 $status="&status=incorrect";
				 }
			}
		}
		if($count_numbering>0&&$complete){
			$sql="UPDATE SBG_Groups
				   SET [Group_Title] = '".$_POST['Group_Title']."'
					  ,[Group_Description] = '".$_POST['Group_Description']."'
					  ,[Group_TotalFileNumbering] = '".$count_numbering."'
				 WHERE Group_ID='".$_POST['Group_ID']."'";
		}else{
			$sql="UPDATE SBG_Groups
				   SET [Group_Title] = '".$_POST['Group_Title']."'
					  ,[Group_Description] = '".$_POST['Group_Description']."'
				 WHERE Group_ID='".$_POST['Group_ID']."'";
		}
		mssql_query($sql);
		$ext="pg-group";
		header("refresh: 0; url=result.php?nextPage=index&ext=$ext$status");
	}else if($_POST['method']=="delete"&&$_POST['Group_ID']){
		$sql="DELETE FROM 
			  SBG_Numberings WHERE Group_ID='".$_POST['Group_ID']."'";
		mssql_query($sql);
		$sql="DELETE FROM 
			  SBG_Groups WHERE Group_ID='".$_POST['Group_ID']."'";
		mssql_query($sql);
		$file_name = "files/".md5($_SESSION['Customer_ID']."_".$_POST['Group_ID']).".txt";
		if(file_exists($file_name)){
			unlink($file_name);
		}
		$ext="pg-group";
		header("refresh: 0; url=result.php?nextPage=index&ext=$ext");
	}else{
		$ext="";
		header("refresh: 0; url=result.php?nextPage=index&ext=$ext&status=error");
	}
}else{
	$ext="";
	header("refresh: 0; url=result.php?nextPage=index&ext=$ext&status=error");
}
?>