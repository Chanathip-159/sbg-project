<?
///////////////////////////// show errors
ini_set('display_errors', 1); 
error_reporting(E_ALL);
/////////////////////////////
$checkError = ini_get('error_reporting');
error_reporting($checkError  ^ E_NOTICE);
/////////////////////////////

$USER = "bulk:0816262131";

?>
<html>

<body>

<form name="form" action="<? $PHP_SELF?>" method="post">
    	<table cellpadding="1" cellspacing="1" align="center"><tr>
    	<td align="center" class="tx_sub_head">Query</td></tr><tr><td>
        <table width="600" bgcolor="#FFFFFF">
			<tr>
        	  <td width="3%">&nbsp;</td>
        	  <td width="25%">&nbsp;</td>
        	  <td width="2%">&nbsp;</td>
        	  <td>&nbsp;</td>
      	    </tr>
			<tr>
				<td height="25">&nbsp;</td>
				<th colspan="4">Fill data by selecting "one" between Sender, Receiver and Transaction ID</th>
				
				<td height="25">&nbsp;</td>
			</tr>
			<tr>
        	  <td height="25">&nbsp;</td>
        	  <td>Sender</td>
        	  <td>:</td>
        	  <td><input name="sms_msisdn_1" type="text" size="20" maxlength="10" />
        	 
       	    </tr>
           	<tr>
        	  <td height="25">&nbsp;</td>
           	  <td>Receiver</td>
            	<td>:</td>
            	<td><input name="sms_msisdn_2" type="text" size="50" />
            	</td>
            </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
           	  <td>Transaction ID</td>
            	<td>:</td>
           	  <td><input name="transaction_id" type="text" size="40" />
           	  </td>
            </tr>
			<tr>
				<td height="10">&nbsp;</td>
				<td></td>
				<td></td>
				<td></td>
			</tr>
        	
		
		   	<tr>
        	  <td height="50" colspan="4" align="center">
			  <input type="hidden" name="method" value="query" />
			  <input type="submit" name="query" value="Query" />
       	      &nbsp;
       	      <input type="reset" name="Reset" id="button" value="Reset" /></td>
       	    </tr>
 </table>
        </td></tr></table>
        </form>
		
		
<?

if(empty($_POST['query'])){
 echo "<br><center>No Report</center>";
 }else{
 
 
 $sender=$_POST['sms_msisdn_1'];
 $receiver=$_POST['sms_msisdn_2'];
 $transaction_id=$_POST['transaction_id'];

 $a=array($_POST['sms_msisdn_1'],$_POST['sms_msisdn_2'],$_POST['transaction_id']);
 
  if((empty($a[0]))&&(empty($a[1]))&&(empty($a[2])))
 {
	echo "<br><center>Please fill data</center>";
 
 }
 
 
 else{
 
 $AND1=" AND sms_msisdn_1 = '".$sender."'";
 $AND2=" AND sms_msisdn_2 = '".$receiver."'";
 $AND3=" AND transaction_id = '".$transaction_id."'";

 $b=array($AND1,$AND2,$AND3);


 for($i=0;$i<=2;$i++)
 {
	if(!empty($a[$i]))
	{
		$tmp=$tmp.$b[$i];
		
	}	
	 
 }
$sql="SELECT * FROM Month01 WHERE command = ".$USER." ".$tmp;   //to be continued

 }

 }

 echo $sql;
 
 ?>
	


	
</body>
</html>		