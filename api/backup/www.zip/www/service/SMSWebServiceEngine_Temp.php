<?php
error_reporting(0); // close error
ini_set('memory_limit', "1024M");
ini_set('always_populate_raw_post_data', "On");

include_once("../api/bulk.api.engine.php");
#define(_URL,"http://10.100.143.143/service/SMSWebServiceEngine.php"); ###
define(_URL,"http://smsgw.cat3g.com/service/SMSWebServiceEngine_Temp.php"); ###

function sendSMS($user, $pass, $from, $target, $mess, $lang) {
	return sendSMSEngine($user, md5($pass), $from, $target, $mess, $lang, null, null);
}

function setLogXmlFile() {
	if (!is_dir(__path_log__."bulk_log_file/")) mkdir(__path_log__."bulk_log_file/", 0777);
	$log_folder = __path_log__."bulk_log_file/".date("Ym")."/";
	if (!is_dir($log_folder)) mkdir($log_folder, 0777);
	return $log_folder."xml_raw_old_gmm_".date("Ymd").".txt";
}


$HTTP_RAW_POST_DATA = trim(isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : '');
$INPUT = trim(file_get_contents('php://input'));


file_put_contents (setLogXmlFile(), date("Y-m-d H:i:s").":: _SERVER\r\n".print_r($_SERVER, true).print_r($HTTP_SERVER_VARS, true)."\r\n", FILE_APPEND | LOCK_EX);

file_put_contents (setLogXmlFile(), date("Y-m-d H:i:s").":: _REQUEST\r\n".print_r($_REQUEST, true)."\r\n", FILE_APPEND | LOCK_EX);
file_put_contents (setLogXmlFile(), date("Y-m-d H:i:s").":: _POST\r\n".print_r($_POST, true)."\r\n", FILE_APPEND | LOCK_EX);
file_put_contents (setLogXmlFile(), date("Y-m-d H:i:s").":: _GET\r\n".print_r($_GET, true)."\r\n", FILE_APPEND | LOCK_EX);

file_put_contents (setLogXmlFile(), date("Y-m-d H:i:s").":: HTTP_RAW_POST_DATA\r\n".print_r($HTTP_RAW_POST_DATA, true)."\r\n", FILE_APPEND | LOCK_EX);
file_put_contents (setLogXmlFile(), date("Y-m-d H:i:s").":: INPUT\r\n".print_r($INPUT, true)."\r\n", FILE_APPEND | LOCK_EX);

file_put_contents (setLogXmlFile(), date("Y-m-d H:i:s").":: _ENV\r\n".print_r($_ENV, true).print_r($HTTP_ENV_VARS, true)."\r\n", FILE_APPEND | LOCK_EX);

file_put_contents (setLogXmlFile(), date("Y-m-d H:i:s").":: _FILES\r\n".print_r($_FILES, true)."\r\n", FILE_APPEND | LOCK_EX);
file_put_contents (setLogXmlFile(), date("Y-m-d H:i:s").":: _COOKIE\r\n".print_r($_COOKIE, true)."\r\n", FILE_APPEND | LOCK_EX);
file_put_contents (setLogXmlFile(), date("Y-m-d H:i:s").":: _SESSION\r\n".print_r($_SESSION, true)."\r\n", FILE_APPEND | LOCK_EX);

if(function_exists('getallheaders')) file_put_contents (setLogXmlFile(), date("Y-m-d H:i:s")."::getallheaders\r\n".print_r(getallheaders(), true)."\r\n", FILE_APPEND | LOCK_EX);
if(function_exists('get_defined_vars')) file_put_contents (setLogXmlFile(), date("Y-m-d H:i:s")."::get_defined_vars\r\n".print_r(get_defined_vars(), true)."\r\n", FILE_APPEND | LOCK_EX);




$php_input = trim(file_get_contents('php://input'));
if ($HTTP_RAW_POST_DATA) {
	$HTTP_RAW_POST_DATA = trim(isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : '');
}elseif ($php_input) {
	$HTTP_RAW_POST_DATA = $php_input;
}else{
	if(strtolower(substr($_SERVER['QUERY_STRING'], 0, 4))=="wsdl") {
		header('Content-Type: text/xml; charset=utf-8');
		echo str_replace("__URL__", _URL, file_get_contents("SMSWebServiceEngine_Temp.wsdl"));
	}else{
		header('Content-Type: text/html; charset=utf-8');
		echo str_replace("__URL__", _URL, file_get_contents("send_sms_function_temp.html"));
	}
	return; // end code
}
if($HTTP_RAW_POST_DATA) {
	$aryXml = xml2Array($HTTP_RAW_POST_DATA);
	$user = $aryXml['Envelope']['Body']['sendSMS']['user'];
	$pass = $aryXml['Envelope']['Body']['sendSMS']['pass'];
	$from = $aryXml['Envelope']['Body']['sendSMS']['from'];
	$target = $aryXml['Envelope']['Body']['sendSMS']['target'];
	$taget = $aryXml['Envelope']['Body']['sendSMS']['taget'];
	if (!empty($taget)) {
		$target = $taget;
	}
	$mess = urldecode($aryXml['Envelope']['Body']['sendSMS']['mess']);
	$lang = $aryXml['Envelope']['Body']['sendSMS']['lang'];
	$result= sendSMS($user, $pass, $from,$target,$mess,$lang);
	header('Content-Type: text/xml; charset=utf-8');
	echo '<SOAP-ENV:Envelope SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:SOAP-ENC="http://schemas.xmlsoap.org/soap/encoding/">
	   <SOAP-ENV:Body>
		  <ns1:sendSMSResponse xmlns:ns1="http://localhost/service/">
			 <return xsi:type="xsd:string">'.$result.'</return>
		  </ns1:sendSMSResponse>
	   </SOAP-ENV:Body>
	</SOAP-ENV:Envelope>';
}
file_put_contents (setLogXmlFile(), date("Y-m-d H:i:s")."::=======================\r\n\r\n", FILE_APPEND | LOCK_EX);
?>
