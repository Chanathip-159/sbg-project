<?
/* require cURL */
define("__URL__","http://smsgw.cat3g.com/service/SMSWebServiceEngine.php");
#define("__URL__","http://10.100.143.143/service/SMSWebServiceEngine.php");

$user="0864601062";
$pass="1062";
$from="test1";
$to="0864601062";
$sms = iconv("windows-874","UTF-8","���ͺ������"); // convert windows-874 to UTF-8
$sms = urlencode($sms); // convert UTF-8 to URL-coding
$lang="T";

$body = '<soapenv:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://localhost/service/">
   <soapenv:Header/>
   <soapenv:Body>
      <ser:sendSMS soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
         <user xsi:type="xsd:string">'.$user.'</user>
         <pass xsi:type="xsd:string">'.$pass.'</pass>
         <from xsi:type="xsd:string">'.$from.'</from>
         <target xsi:type="xsd:string">'.$to.'</target>
         <mess xsi:type="xsd:string">'.$sms.'</mess>
         <lang xsi:type="xsd:string">'.$lang.'</lang>
      </ser:sendSMS>
   </soapenv:Body>
</soapenv:Envelope>
';
echo SendWebService($body);

function SendWebService ($body) {
	$opts = array(
		'http' =>array(
			'method'  => 'POST',
			'header'  => "Content-Type: text/xml; charset=utf-8\r\nContent-length: ".strlen($body)."\r\n",
			'content' => $body,
			'timeout' => 30
			)
		,'ssl' => array(
			'allow_self_signed'=>true,
			'verify_peer'=>false
		)
	);
	$context  = stream_context_create($opts);
	$result = file_get_contents(__URL__, false, $context);
	return $result;
}
?>