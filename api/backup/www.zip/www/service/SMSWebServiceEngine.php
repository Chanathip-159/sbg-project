<?php
error_reporting(0); // close error
ini_set("memory_limit", "1024M");
include_once("../api/bulk.api.engine.php");
#define(_URL,"http://10.100.143.143/service/SMSWebServiceEngine.php"); ###
define(_URL,"http://smsgw.cat3g.com/service/SMSWebServiceEngine.php"); ###

function sendSMS($user, $pass, $from, $target, $mess, $lang) {
	return sendSMSEngine($user, md5($pass), $from, $target, $mess, $lang, null, null);
}

function setLogXmlFile() {
	if (!is_dir(__path_log__."bulk_log_file/")) mkdir(__path_log__."bulk_log_file/", 0777);
	$log_folder = __path_log__."bulk_log_file/".date("Ym")."/";
	if (!is_dir($log_folder)) mkdir($log_folder, 0777);
	return $log_folder."xml_raw_old_".date("Ymd").".txt";
}

if ($HTTP_RAW_POST_DATA) {
	$HTTP_RAW_POST_DATA = trim(isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : '');
}elseif ($_POST) {
	$HTTP_RAW_POST_DATA = trim(file_get_contents('php://input'));
}else{
	if(strtolower(substr($_SERVER['QUERY_STRING'], 0, 4))=="wsdl") {
		header('Content-Type: text/xml; charset=utf-8');
		echo str_replace("__URL__", _URL, file_get_contents("SMSWebserviceEngine.wsdl"));
	}else{
		header('Content-Type: text/html; charset=utf-8');
		echo str_replace("__URL__", _URL, file_get_contents("send_sms_function.html"));
	}
	return; // end code
}
#file_put_contents (setLogXmlFile(), date("Y-m-d H:i:s")."::\r\n$HTTP_RAW_POST_DATA\r\n", FILE_APPEND | LOCK_EX);
if($HTTP_RAW_POST_DATA) {
	$aryXml = xml2Array($HTTP_RAW_POST_DATA);
	$user = $aryXml['Envelope']['Body']['sendSMS']['user'];
	$pass = $aryXml['Envelope']['Body']['sendSMS']['pass'];
	$from = $aryXml['Envelope']['Body']['sendSMS']['from'];
	$target = $aryXml['Envelope']['Body']['sendSMS']['target'];
	$taget = $aryXml['Envelope']['Body']['sendSMS']['taget'];
	if (!empty($taget)) {
		$target = $taget;
	}
	$mess = urldecode($aryXml['Envelope']['Body']['sendSMS']['mess']);
	$lang = $aryXml['Envelope']['Body']['sendSMS']['lang'];
	$result= sendSMS($user, $pass, $from,$target,$mess,$lang);
	header('Content-Type: text/xml; charset=utf-8');
	echo '<SOAP-ENV:Envelope SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/" xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:SOAP-ENC="http://schemas.xmlsoap.org/soap/encoding/">
	   <SOAP-ENV:Body>
		  <ns1:sendSMSResponse xmlns:ns1="http://localhost/service/">
			 <return xsi:type="xsd:string">'.$result.'</return>
		  </ns1:sendSMSResponse>
	   </SOAP-ENV:Body>
	</SOAP-ENV:Envelope>';
}
?>
