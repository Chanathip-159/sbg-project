<?
/**********mssql Server Path*******************/
$dbhost="10.100.143.100"; //10.99.4.170
$dbuser="sa"; //jidapa
$dbpass="V@5my"; //P@ssDB
$dbname="VAS";

//**********Connect MSSQL*******************/
$con=mssql_connect($dbhost,$dbuser,$dbpass) or die("CAN'T CONNECT DATABASE SERVER");
mssql_select_db($dbname,$con) or die("CAN'T CONNECT DATABASE  $dbname ");
ini_set("memory_limit", "25M");
ini_set('max_execution_time',240);

$bg_form="#E2E4FF";
$bg_menu="#AAAEEC";
$bg_tableBorder="#A8ACE3";
$bg_tableHead="#A8ACE3";
$bg_tableEven="#FFFFFF";
$bg_tableOdd="#E1E2FA";

/*
$page1=explode("/",$HTTP_SERVER_VARS['REQUEST_URI']);
$page2=explode(".php",$page1[1]);
$page3=explode("_",$page2[0]);
if(count($page3)<>0){
	$page=$page3[0];
}else{
	$page=$page2[0];
}
if($page<>"permission"){include("check_permission.php");}
*/
?>