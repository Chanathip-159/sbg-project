<?php
error_reporting(0); // close error
ini_set("memory_limit", "1024M");
include_once("bulk.api.engine.php");
echo sendSMSEngine($_POST['user'], md5($_POST['pass']), $_POST['from'], $_POST['target'], $_POST['mess'], $_POST['lang'], $_POST['expire'], $_POST['scheduled']);
?>
