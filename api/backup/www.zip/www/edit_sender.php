<?
ob_start();
include("config.php");?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css" title="currentStyle">
@import "DataTable/css/demo_page.css";
 @import "DataTable/css/demo_table.css";
</style>
<script type="text/javascript" language="javascript" src="DataTable/js/jquery.js"></script>
<script type="text/javascript" language="javascript" src="DataTable/js/jquery.dataTables.js"></script>
<script type="text/javascript" charset="utf-8">
	$.fn.dataTableExt.oApi.fnGetHiddenTrNodes = function ( oSettings ){
		var anNodes = this.oApi._fnGetTrNodes( oSettings );
		var anDisplay = $('tbody tr', oSettings.nTable);
		for ( var i=0 ; i<anDisplay.length ; i++ ){
			var iIndex = jQuery.inArray( anDisplay[i], anNodes );
			if ( iIndex != -1 ){
				anNodes.splice( iIndex, 1 );
			}
		}
		return anNodes;
	}
	var oTable;
	$(document).ready(function() {
		var oTable = $('#example').dataTable();
		$('#button').click( function () {
			var nHidden = oTable.fnGetHiddenTrNodes( );
			alert( nHidden.length +' nodes were returned' );
		} );
	} );
</script>
<script type="text/javascript" language="javascript" src="js/jquery-1.10.2.js"></script>
<script type="text/javascript">
	var counter;
	$(document).ready(function() {
		var counter = 2;
		$('#addButton').click(function () {
			if(counter>5){
				alert("Only 5 Sender Names allow");
				return false;
			}   
		var newTextBoxDiv = $(document.createElement('div')).attr("id", 'TextBoxDiv' + counter);
		newTextBoxDiv.after().html('<input name="Sender_Name' + counter + '" type="text" id="Sender_Name' + counter + '" size="20" />');
		newTextBoxDiv.appendTo("#TextBoxesGroup");
		counter++;
		});
		$('#removeButton').click(function () {
			if(counter==2){
				alert("Please fill at least 1 Sender Name");
				return false;
			}   
		counter--;
		$("#TextBoxDiv" + counter).remove();
		});
    });
</script>


<script language="javascript" type="text/javascript">
<!--  
function ValidateSender(form_sender){

	if (form.Sender_Name.value == ""){
		alert("Customer's account is required!");
		form.Sender_Name.focus();
		return false;
	}

	return true;
}  
//--> 
</script>
<head>
hello
</head>
<br><br>

<?


$sql ="SELECT * FROM SBG_Senders WHERE Customer_ID='".$_POST['Request_ID']."'";
$mssql = mssql_query($sql);
if(empty($_POST['edit_sender'])){
	$sql_1=mssql_query("SELECT * From SBG_Customers where Customer_ID ='".$_POST['Request_ID']."'");
	$sql_2=mssql_query("SELECT * From SBG_Senders where Customer_ID ='".$_POST['Request_ID']."'");
	$edit_1=mssql_fetch_array($sql_1);
		
	$i=0;
	
	
?>
     <form name="form_sender" action="edit_sender.php" method="post" onsubmit="return ValidateSender(this)">
    	<table cellpadding="1" cellspacing="1" bgcolor="<?=$bg_form?>" align="center">
		<tr>
    	<td align="center" class="tx_sub_head">Customer Edit (Sender) Form</td></tr>
		<tr>
		<td>
        <table width="600" bgcolor="#FFFFFF">
        	<tr>
				<td width="3%">&nbsp;</td>
				<td width="25%">&nbsp;</td>
				<td width="2%">&nbsp;</td>
				<td>&nbsp;</td>
      	    </tr>
        	<tr>
				<td height="25">&nbsp;</td>
				<td>Sender Name</td>
				<td>:</td>
				<td>
<?
while($edit_2=mssql_fetch_array($sql_2){ 
		$i++;
?>		
				<?=$edit_2['Sender_Name']?><?=$edit_2['Sender_ID']?>
<?
}
?>					
			</td>
			</tr>
		</table>
		</td>
		</tr>
		</table>
	  </form>
		



		
	
    
	
	
<?	

ob_end_flush(); /*<input type="hidden" name="Sender_ID" value="<?=$edit_2['Sender_ID'?>"/> */
?>