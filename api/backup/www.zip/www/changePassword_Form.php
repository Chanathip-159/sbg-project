<? 
include("config.php");
if(!empty($_SESSION['Customer_ID'])){
	$sql = "SELECT Customer_Account, Customer_Password FROM SBG_Customers WHERE Customer_ID='".$_SESSION['Customer_ID']."'";
}else if(!empty($_SESSION['Admin_ID'])){
	$sql = "SELECT Admin_Account, Admin_Password FROM SBG_Admins WHERE Admin_ID='".$_SESSION['Admin_ID']."'";
}
$mssql = mssql_query($sql);
$edit = mssql_fetch_array($mssql);
?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<script language="javascript" type="text/javascript">
<!--  
function ValidatePassword(form){
	if (form.New_Password.value == ""){
		alert("Your new password is required!");
		form.New_Password.focus();
		return false;
	}  
	if (form.Confirm_Password.value == ""){
		alert("Your confirm password is required!");
		form.Confirm_Password.focus();
		return false;
	}  
	if (form.New_Password.value != form.Confirm_Password.value){
		alert("Your password not match");
		form.Confirm_Password.focus();
		return false;
	}
	return true;
}  
//--> 
</script><br /><br />
<form name="formEdit" action="changePassword_Query.php" method="post" onsubmit="return ValidatePassword(this)">
  <table cellpadding="1" cellspacing="1" bgcolor="<?=$bg_form?>" align="center">
    <tr>
      <td align="center" class="tx_sub_head">Change Password Form</td>
    </tr>
    <tr>
      <td><table width="500" align="center" bgcolor="#FFFFFF">
          <tr>
            <td width="15%">&nbsp;</td>
            <td width="25%">&nbsp;</td>
            <td width="2%">&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>New Password</td>
            <td>:</td>
            <td><input name="New_Password" type="password" size="25" /></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>Confirm Password</td>
            <td>:</td>
            <td><input name="Confirm_Password" type="password" size="25" /></td>
          </tr>
          <tr>
            <td height="50" colspan="4" align="center"><input type="hidden" name="method" value="edit" />
              <input type="submit" name="Submit" value="Submit" /></td>
          </tr>
        </table></td>
    </tr>
  </table>
</form>
<br /><br />