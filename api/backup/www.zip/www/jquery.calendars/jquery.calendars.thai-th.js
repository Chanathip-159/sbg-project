﻿/* http://keith-wood.name/calendars.html
   Thai localisation for Thai calendars for jQuery.
   Written by pipo (pipo@sixhead.com). */
(function($) {
	$.calendars.calendars.thai.prototype.regional['th'] = {
		name: 'Thai',
		epochs: ['BBE', 'BE'],
		monthNames: ['Janualy','Febuary','March','April','May','June',
		'July','August','September','October','November','December'],
		monthNamesShort: ['Jan','Feb','Mar','Apr','May','Jun',
		'Jul','Aug','Sep','Oct','Nov','Dec'],
		dayNames: ['Sun','Mon','Thu','Wed','Thr','Fri','Sat'],
		dayNamesShort: ['S','M','T','W','Th','F','S'],
		dayNamesMin: ['S','M','T','W','Th','F','S'],
		dateFormat: 'dd/mm/yyyy',
		firstDay: 0,
		isRTL: false
	};
})(jQuery);
