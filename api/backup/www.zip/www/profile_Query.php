<?
session_start();
include("config.php");
include("fn/fn.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
<link href="css/style.css" rel="stylesheet" type="text/css">
<?
$date_now=Date("Y-m-j H:i:s");
if(!empty($_SESSION['Customer_ID'])){ //Check Session
	if($_POST['method']=="edit"&&$_SESSION['Customer_ID']){
		$sql="UPDATE SBG_Customers
			   SET [Customer_Title] = '".$_POST['Customer_Title']."'
				  ,[Customer_Contact] = '".$_POST['Customer_Contact']."'
				  ,[Customer_Address] = '".$_POST['Customer_Address']."'
				  ,[Customer_Telephone] = '".$_POST['Customer_Telephone']."'
				  ,[Customer_Fax] = '".$_POST['Customer_Fax']."'
				  ,[Customer_Email] = '".$_POST['Customer_Email']."'
				  ,[Customer_Remark] = '".$_POST['Customer_Remark']."'
			 WHERE Customer_ID='".$_SESSION['Customer_ID']."'";
		mssql_query($sql);
		$ext="pg-profile";
		header("refresh: 0; url=result.php?nextPage=index&ext=$ext");
	}else{
		$ext="";
		header("refresh: 0; url=result.php?nextPage=index&ext=$ext&status=error");
	}
}else if(!empty($_SESSION['Admin_ID'])){
	if($_POST['method']=="edit"&&$_SESSION['Admin_ID']){
		$sql="UPDATE SBG_Admins
			   SET [Admin_Department] = '".$_POST['Admin_Department']."'
				  ,[Admin_FullName] = '".$_POST['Admin_FullName']."'
			 WHERE Admin_ID='".$_SESSION['Admin_ID']."'";
		mssql_query($sql);
		$ext="pg-profile";
		header("refresh: 0; url=result.php?nextPage=index&ext=$ext");
	}else{
		$ext="";
		header("refresh: 0; url=result.php?nextPage=index&ext=$ext&status=error");
	}
}else{
	$ext="";
	header("refresh: 0; url=result.php?nextPage=index&ext=$ext&status=error");
}
?>