<?
ob_start();
session_start();
$bg="#CCFFCC";
$time=2;
if(empty($_GET['status'])){
	$message="Saving...";
}else if($_GET['status']=="repeat"){
	$message="Duplicate data...";
	$bg="#FF9999";
}else if($_GET['status']=="incorrect"){
	$time=5;
	$message="<p>Data format  is incorrect, data format is mobile number 10 digits only, for example<br />0860900000<br />0860905555<br />0800907777</p><p>please upload again</p>";
	$bg="#FF9999";
}else if($_GET['status']=="error"){
	$message="Not found command...";
	$bg="#FF9999";
}
require_once("config.php");
require_once("fn/fn.php");
if(!empty($_POST['pg'])){
	$pg=$_POST['pg'];
}else if(!empty($_GET['pg'])){
	$pg=$_GET['pg'];
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<title>SBG</title>
<link href="css/style.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="js/localtime.js"></script>
</head>
<body>
<div class="container">
  <div class="menutop">
    <table width="100%" cellpadding="0" cellspacing="0" bgcolor="#ccc">
      <tr>
        <td height="40" valign="middle" class="tx_FullNameOffice_">&nbsp;SMS Bulk Gateway System (SBGS)</td>
        <td align="right" valign="middle" class="tx_sub_head">Login By: <? if(!empty($_SESSION['Customer_Account'])){echo $_SESSION['Customer_Account']." (Customer)&nbsp;";}else if(!empty($_SESSION['Admin_Account'])){echo $_SESSION['Admin_Account']." (Admin)&nbsp;";}?></td>
      </tr>
    </table>
  </div>
  <div class="menusub">
  	<? include("menu.php");?>
  </div>
  <div class="bodycontent">
  	<br />
    <br />
    <br />
    <table cellpadding="1" cellspacing="1" bgcolor="<?=$bg?>" align="center">
      <tr>
        <td align="center">Status</td>
      </tr>
      <tr>
        <td><table width="500" bgcolor="#FFFFFF">
            <tr>
              <td align="center"><br />
                <br />
                <img src="image/loading.gif" /><br />
                <?=$message?>
                <br />
                <br />
                <br /></td>
            </tr>
            <?
                $subfix = str_replace(",", "&", $_GET['ext']);
                $subfix = str_replace("-", "=", $subfix);
                $link = $_GET['nextPage'].".php"."?".$subfix;
                header("refresh: $time; url=$link");
            ?>
          </table></td>
      </tr>
    </table>
    <br />
    <br />
<br />
    &nbsp; </div>
  <div class="menubottom">
    <? //require_once("menu_bottom.php");?>
  </div>
</div>
<div class="copy">
  <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="<?=$bg_menu?>">
    <tr>
      <td width="3%" height="20"><b>&nbsp;Copyright &copy; 2013 mybycat</b></td>
      <td width="4%" align="right"><b>Admin Contact: 02-104-4740&nbsp;</b></td>
    </tr>
  </table>
</div>
</body>
</html>
<?ob_end_flush();?>