<? include("config.php");?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<script language="javascript" type="text/javascript">
<!--  
function ValidateNumbering(form){
	var telFilter = /^0[0-9]{9}$/; //tel fax regular expression
	var tel = document.form.Number_No.value;
	if (form.Number_No.value == ""){
		alert("Your numbering is required!");
		form.Number_No.focus();
		return false;
	}
	if (!(telFilter.test(tel))){
		alert("Not a valid mobile number");
		form.Number_No.focus();
		return false;
	}
	return true;
}  
//--> 
</script>
<style type="text/css" title="currentStyle">
@import "DataTable/css/demo_page.css";
 @import "DataTable/css/demo_table.css";
</style>
<script type="text/javascript" language="javascript" src="DataTable/js/jquery.js"></script>
<script type="text/javascript" language="javascript" src="DataTable/js/jquery.dataTables.js"></script>
<script type="text/javascript" charset="utf-8">
	$.fn.dataTableExt.oApi.fnGetHiddenTrNodes = function ( oSettings ){
		var anNodes = this.oApi._fnGetTrNodes( oSettings );
		var anDisplay = $('tbody tr', oSettings.nTable);
		for ( var i=0 ; i<anDisplay.length ; i++ ){
			var iIndex = jQuery.inArray( anDisplay[i], anNodes );
			if ( iIndex != -1 ){
				anNodes.splice( iIndex, 1 );
			}
		}
		return anNodes;
	}
	var oTable;
	$(document).ready(function() {
		var oTable = $('#example').dataTable();
		$('#button').click( function () {
			var nHidden = oTable.fnGetHiddenTrNodes( );
			alert( nHidden.length +' nodes were returned' );
		} );
	} );
</script>

<link type="text/css" href="jquery.calendars/humanity.calendars.picker.css" rel="stylesheet"/>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.min.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.plus.min.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.picker.min.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.thai.min.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.thai-th.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.picker-th.js"></script>
<script type="text/javascript">
$(function() {
	$('#RegisDate').calendarsPicker({ minDate: "-12M -0D", maxDate:0, dateFormat:"yyyy-mm-dd", calendar: $.calendars.instance('thai','th')});
	$('#ExpireDate').calendarsPicker({ minDate: "-12M -0D", maxDate:"+12M +0D", dateFormat:"yyyy-mm-dd", calendar: $.calendars.instance('thai','th')});
});

</script>

<?
if(!empty($_POST['Group_ID'])){
	$Group_ID=$_POST['Group_ID'];
}else if(!empty($_GET['Group_ID'])){
	$Group_ID=$_GET['Group_ID'];
}else{
	$Group_ID="";
}
list($Group_Title)=mssql_fetch_array(mssql_query("SELECT Group_Title FROM SBG_Groups WHERE Group_ID='".$Group_ID."'"));
$sql ="SELECT * FROM SBG_Numberings WHERE Group_ID='".$Group_ID."' ORDER BY Number_No";
$mssql = mssql_query($sql);
$rows = mssql_num_rows($mssql);
?>
    <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
      <form name="formCreateButton" action="<? $PHP_SELF?>" method="post">
      <tr>
        <td valign="top" class="tx_sub_head">Numberings of <?=$Group_Title?> group</td>
        <td align="right" class="tx_sub_head">
        <? if(empty($_POST['create'])&&empty($_POST['edit'])&&empty($_POST['delete'])){?>
        <? if($rows<100){$number_balance=100-$rows;?>
        <input type="hidden" name="Group_ID" value="<?=$Group_ID?>" />
        <input type="submit" class="button_form" name="create" value="Create numbering (Remain <?=$number_balance?> numberings)" />
        <? }?>
        <? }?>
        </td>
      </tr>
      </form>
    </table>
<? if(empty($_POST['create'])&&empty($_POST['edit'])&&empty($_POST['delete'])){?>
    <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td colspan="2"><div id="demo">
            <table cellpadding="0" cellspacing="0" border="0" class="display" id="example">
              <thead>
                <tr>
                  <th>No.</th>
                  <th>Numbering</th>
                  <th><p>Create</p></th>
                  <th>Revise</th>
                  <th>Edit</th>
                  <th>Del.</th>
                </tr>
              </thead>
              <tbody>
              <? $i=0;while($data=mssql_fetch_array($mssql)){ $i++;?>
                <tr class="<?=$bg?>" onMouseOver="this.bgColor='#FFFFFF';" onMouseOut="this.bgColor='<?=$bg?>';">
                  <td align="center"><?=$i?></td>
                  <td><?=$data['Number_No']?></td>
                  <td align="center"><?=substr($data['Number_CreateDate'],0,16)?></td>
                  <td align="center"><?=substr($data['Number_UpDate'],0,16)?></td>
                  <form name="formEditButton" action="<? $PHP_SELF?>" method="post">
                  <td align="center">
                  <input type="hidden" name="Group_ID" value="<?=$Group_ID?>" />
                  <input type="hidden" name="Number_ID" value="<?=$data['Number_ID']?>" />
                  <input type="image" src="image/edit.gif" name="edit" value="Edit" />
                  </td>
                  </form>
                  <form name="formDeleteButton" action="number_Query.php" method="post">
                  <td align="center">
                  <input type="hidden" name="Group_ID" value="<?=$Group_ID?>" />
                  <input type="hidden" name="Number_ID" value="<?=$data['Number_ID']?>" />
                  <input type="hidden" name="method" value="delete" />
                  <input type="image" src="image/delete.gif" name="delete" value="Delete" onclick="return confirm('Are you sure you want to delete this?')" />
                  </td>
                  </form>
                </tr>
               <? }?>
            </table>
          </div>
          <div class="spacer"></div></td>
      </tr>
    </table>
	<? }else{echo "<br><br>";
		if(!empty($_POST['create'])&&$rows<100){?>
    	<form name="form" action="number_Query.php" method="post" onsubmit="return ValidateNumbering(this)">
    	<table cellpadding="1" cellspacing="1" bgcolor="<?=$bg_form?>" align="center"><tr>
    	<td align="center" class="tx_sub_head">Numberings Create Form</td></tr><tr><td>
        <table width="500" bgcolor="#FFFFFF">
        	<tr>
        	  <td width="25%">&nbsp;</td>
        	  <td width="20%">&nbsp;</td>
        	  <td width="3%">&nbsp;</td>
        	  <td>&nbsp;</td>
      	    </tr>
        	<tr>
        	  <td>&nbsp;</td>
            	<td>Numbering</td>
            	<td>:</td>
            	<td><input name="Number_No" type="text" size="15" />
            	  *</td>
            </tr>
        	<tr>
        	  <td height="50" colspan="4" align="center"><input name="Rows" type="hidden" value="<?=$rows?>" />
       	      <input type="hidden" name="method" value="create" /><input type="hidden" name="Group_ID" value="<?=$Group_ID?>" /><input type="submit" name="Submit" value="Submit" /></td>
       	    </tr>
        </table>
        </td></tr></table>
        </form>
    <? 
	}else if(!empty($_POST['edit'])){
		$edit=mssql_fetch_array(mssql_query("SELECT * FROM SBG_Numberings WHERE Number_ID='".$_POST['Number_ID']."'"));
	?>
    	<form name="form" action="number_Query.php" method="post" onsubmit="return ValidateNumbering(this)">
    	<table cellpadding="1" cellspacing="1" bgcolor="<?=$bg_form?>" align="center"><tr>
    	<td align="center" class="tx_sub_head">Numberings Edit Form</td></tr><tr><td>
        <table width="500" align="center" bgcolor="#FFFFFF">
          <tr>
            <td width="25%">&nbsp;</td>
            <td width="20%">&nbsp;</td>
            <td width="3%">&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>Numbering</td>
            <td>:</td>
            <td><input name="Number_No" type="text" size="15" value="<?=$edit['Number_No']?>" />
            *</td>
          </tr>
        	<tr>
        	  <td height="50" colspan="4" align="center">
        	    <input type="hidden" name="method" value="edit" />
        	    <input type="hidden" name="Number_ID" value="<?=$_POST['Number_ID']?>" />
        	    <input type="hidden" name="Group_ID" value="<?=$_POST['Group_ID']?>" />
                <input type="submit" name="Submit" value="Submit" />
                </td>
      	  </tr>
        </table>
        </td></tr></table>
        </form>
     <? }?>
<? echo "<br><br>";}?>