<? include("config.php");?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css" title="currentStyle">
@import "DataTable/css/demo_page.css";
 @import "DataTable/css/demo_table.css";
</style>
<script type="text/javascript" language="javascript" src="DataTable/js/jquery.js"></script>
<script type="text/javascript" language="javascript" src="DataTable/js/jquery.dataTables.js"></script>
<script type="text/javascript" charset="utf-8">
	$.fn.dataTableExt.oApi.fnGetHiddenTrNodes = function ( oSettings ){
		var anNodes = this.oApi._fnGetTrNodes( oSettings );
		var anDisplay = $('tbody tr', oSettings.nTable);
		for ( var i=0 ; i<anDisplay.length ; i++ ){
			var iIndex = jQuery.inArray( anDisplay[i], anNodes );
			if ( iIndex != -1 ){
				anNodes.splice( iIndex, 1 );
			}
		}
		return anNodes;
	}
	var oTable;
	$(document).ready(function() {
		var oTable = $('#example').dataTable();
		$('#button').click( function () {
			var nHidden = oTable.fnGetHiddenTrNodes( );
			alert( nHidden.length +' nodes were returned' );
		} );
	} );
</script>

<link type="text/css" href="jquery.calendars/humanity.calendars.picker.css" rel="stylesheet"/>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.min.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.plus.min.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.picker.min.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.thai.min.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.thai-th.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.picker-th.js"></script>
<script type="text/javascript">
$(function() {
	$('#RegisDate').calendarsPicker({ minDate: "-12M -0D", maxDate:0, dateFormat:"yyyy-mm-dd", calendar: $.calendars.instance('thai','th')});
	$('#ExpireDate').calendarsPicker({ minDate: "-12M -0D", maxDate:"+12M +0D", dateFormat:"yyyy-mm-dd", calendar: $.calendars.instance('thai','th')});
});

</script>

<script language="javascript" type="text/javascript">
<!--  
function ValidateAdmin(form){
	var accountFilter = /^[0-9]{6,7}$/; //email regular expression
	var account = document.form.Admin_Account.value;
	
	if (form.Admin_Account.value == ""){
		alert("Administrator's account is required!");
		form.Admin_Account.focus();
		return false;
	}  
	if (!(accountFilter.test(account))){
		alert("Not a valid account, please input only number 6 digits");
		form.Admin_Account.focus();
		return false;
	}
	if (form.Admin_FullName.value == ""){
		alert("Administrator's full name is required!");
		form.Admin_FullName.focus();
		return false;
	}  
	if (form.Admin_Department.value == ""){
		alert("Administrator's department is required!");
		form.Admin_Department.focus();
		return false;
	} 
	return true;
}  
//--> 
</script>
<?
$sql ="SELECT * FROM SBG_Admins ORDER BY Admin_Account";
$mssql = mssql_query($sql);
if(empty($_POST['create'])&&empty($_POST['edit'])&&empty($_POST['delete'])){
?>
    <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
      <form name="formCreateButton" action="<? $PHP_SELF?>" method="post">
      <tr>
        <td valign="top" class="tx_sub_head">Adminstrators</td>
        <td align="right" class="tx_sub_head"><input type="submit" class="button_form" name="create" value="Create administrator" /></td>
      </tr>
      </form>
    </table>
    <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td colspan="2"><div id="demo">
            <table cellpadding="0" cellspacing="0" border="0" class="display" id="example">
              <thead>
                <tr>
                  <th>No.</th>
                  <th>Account</th>
                  <th>Name</th>
                  <th>Department</th>
                  <th>Create</th>
                  <th>Update</th>
                  <th>Reset P/W</th>
                  <th>Edit</th>
                  <th>Del.</th>
                </tr>
              </thead>
              <tbody>
              <? $i=0;while($data=mssql_fetch_array($mssql)){ $i++;?>
                <tr class="<?=$bg?>" onMouseOver="this.bgColor='#FFFFFF';" onMouseOut="this.bgColor='<?=$bg?>';">
                  <td align="center"><?=$i?></td>
                  <td align="center"><?=$data['Admin_Account']?></td>
                  <td><?=$data['Admin_FullName']?></td>
                  <td align="center"><?=$data['Admin_Department']?></td>
                  <td align="center"><?=substr($data['Admin_CreateDate'],0,16)?></td>
                  <td align="center"><?=substr($data['Admin_UpDate'],0,16)?></td>
                  <form name="formResetButton" action="user_Query.php" method="post">
                  <td align="center">
                  <input type="hidden" name="Admin_No" value="<?=$data['Admin_Account']?>" />
                  <input type="hidden" name="User_Account" value="<?=md5(md5($data['Admin_Account']))?>" />
                  <input type="hidden" name="Request_ID" value="<?=$data['Admin_ID']?>" />
                  <input type="hidden" name="method" value="reset" />
                  <input type="image" src="image/pw.png" name="reset" value="reset" onclick="return confirm('Are you sure you want to reset password?')" />
                  </td>
                  </form>
                  <form name="formEditButton" action="<? $PHP_SELF?>" method="post">
                  <td align="center">
                  <input type="hidden" name="Admin_Account" value="<?=md5(md5($data['Admin_Account']))?>" />
                  <input type="hidden" name="Request_ID" value="<?=$data['Admin_ID']?>" />
                  <input type="image" src="image/edit.gif" name="edit" value="Edit" />
                  </td>
                  </form>
                  <form name="formDeleteButton" action="user_Query.php" method="post">
                  <td align="center">
                  <input type="hidden" name="Admin_Account" value="<?=md5(md5($data['Admin_Account']))?>" />
                  <input type="hidden" name="Request_ID" value="<?=$data['Admin_ID']?>" />
                  <input type="hidden" name="method" value="delete" />
                  <input type="image" src="image/delete.gif" name="delete" value="Delete" onclick="return confirm('Are you sure you want to delete this?')" />
                  </td>
                  </form>
                </tr>
               <? }?>
            </table>
          </div>
          <div class="spacer"></div></td>
      </tr>
    </table>
	<? }else{echo "<br><br>";
		if(!empty($_POST['create'])){?>
    	<form name="form" action="user_Query.php" method="post" onsubmit="return ValidateAdmin(this)">
    	<table cellpadding="1" cellspacing="1" bgcolor="<?=$bg_form?>" align="center"><tr>
    	<td align="center" class="tx_sub_head">Administrator create form</td></tr><tr><td>
        <table width="600" bgcolor="#FFFFFF">
        	<tr>
        	  <td width="3%">&nbsp;</td>
        	  <td width="25%">&nbsp;</td>
        	  <td width="2%">&nbsp;</td>
        	  <td>&nbsp;</td>
      	    </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
        	  <td>Account</td>
        	  <td>:</td>
        	  <td><input name="Admin_Account" type="text" size="20" maxlength="10" />
        	  *        	    </td>
      	  </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
           	  <td>Name</td>
            	<td>:</td>
            	<td><input name="Admin_FullName" type="text" size="50" />
            	*</td>
            </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
           	  <td>Department</td>
            	<td>:</td>
            	<td><input name="Admin_Department" type="text" size="50" />
            	*</td>
            </tr>
        	<tr>
        	  <td height="50" colspan="4" align="center"><input type="hidden" name="method" value="create" /><input type="submit" name="Submit" value="Submit" /></td>
       	    </tr>
        </table>
        </td></tr></table>
        </form>
    <? 
	}else if(!empty($_POST['edit'])){
		$edit=mssql_fetch_array(mssql_query("SELECT * FROM SBG_Admins WHERE Admin_ID='".$_POST['Request_ID']."'"));
	?>
    	<form name="form" action="user_Query.php" method="post" onsubmit="return ValidateAdmin(this)">
    	<table cellpadding="1" cellspacing="1" bgcolor="<?=$bg_form?>" align="center"><tr>
    	<td align="center" class="tx_sub_head">Administrator edit form</td></tr><tr><td>
        <table width="600" align="center" bgcolor="#FFFFFF">
          <tr>
            <td width="3%">&nbsp;</td>
            <td width="25%">&nbsp;</td>
            <td width="2%">&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td height="25">&nbsp;</td>
            <td>Account</td>
            <td>:</td>
            <td><?=$edit['Admin_Account']?></td>
          </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
        	  <td>Name</td>
           	  <td>:</td>
            	<td><input name="Admin_FullName" type="text" size="50" value="<?=$edit['Admin_FullName']?>" />
            	*</td>
            </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
        	  <td>Department</td>
           	  <td>:</td>
            	<td><input name="Admin_Department" type="text" size="50" value="<?=$edit['Admin_Department']?>" />
            	*</td>
            </tr>
        	<tr>
        	  <td height="50" colspan="4" align="center"><input type="hidden" name="Request_ID" value="<?=$edit['Admin_ID']?>" />
        	    <input type="hidden" name="method" value="edit" />
        	    <input type="submit" name="Submit" value="Submit" /></td>
      	  </tr>
        </table>
        </td></tr></table>
        </form>
     <? }?>
<? echo "<br><br>";}?>