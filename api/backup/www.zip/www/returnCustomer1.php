<?php
	$objConnect = mssql_connect("10.99.4.170","jidapa","P@ssDB") or die("CAN'T CONNECT DATABASE SERVER");
	$objDB = mssql_select_db("VAS");
	$strSQL = "SELECT * FROM customer WHERE 1 AND CustomerID = '".$_POST["sCusID"]."' OR Email = '".$_POST["eMail"]."' ";
	$objQuery = mssql_query($strSQL);
	$intNumField = mssql_num_fields($objQuery);
	$resultArray = array();
	while($obResult = mssql_fetch_array($objQuery))
	{
		$arrCol = array();
		for($i=0;$i<$intNumField;$i++)
		{
			$arrCol[mssql_field_name($objQuery,$i)] = $obResult[$i];
		}
		array_push($resultArray,$arrCol);
	}
	
	mssql_close($objConnect);
	
	echo json_encode($resultArray);
?>