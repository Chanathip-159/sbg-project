<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>SBG</title>
<style type="text/css">
body p {
	font-family: Verdana, Geneva, sans-serif;
}
body p {
	font-size: smaller;
}
</style>
</head>

<body>
<form name = "sender" action = "send_Query.php" method = "POST">
<table width="500" bgcolor="#FFFFFF" align="center">
        	<tr>
        	  <td width="3%">&nbsp;</td>
        	  <td width="30%">&nbsp;</td>
        	  <td width="2%">&nbsp;</td>
        	  <td>&nbsp;</td>
      	    </tr>
        	<tr>
        	  <td>&nbsp;</td>
            	<td>Sender</td>
            	<td>:</td>
            	<td><input name="Sender_Name" type="text" size="30" /></td>
            </tr>
        	<tr>
        	  <td>&nbsp;</td>
            	<td>Receiver</td>
            	<td>:</td>
            	<td><input name="Receiver_1" type="text" size="30" /></td>
            </tr>
               	<tr>
        	  <td>&nbsp;</td>
            	<td>&nbsp;</td>
            	<td>:</td>
            	<td><input name="Receiver_2" type="text" size="30" /></td>
            </tr>   	<tr>
        	  <td>&nbsp;</td>
            	<td>&nbsp;</td>
            	<td>:</td>
            	<td><input name="Receiver_3" type="text" size="30" /></td>
            </tr>   	<tr>
        	  <td>&nbsp;</td>
            	<td>&nbsp;</td>
            	<td>:</td>
            	<td><input name="Receiver_4" type="text" size="30" /></td>
            </tr>   	<tr>
        	  <td>&nbsp;</td>
            	<td>&nbsp;</td>
            	<td>:</td>
            	<td><input name="Receiver_5" type="text" size="30" /></td>
            </tr>
        	<tr>
        	  <td valign="top">&nbsp;</td>
            	<td valign="top">text</td>
            	<td valign="top">:</td>
            	<td><textarea name="Message" cols="40" rows="5"></textarea></td>
            </tr>
        	<tr>
        	  <td>&nbsp;</td>
            	<td>Number of message</td>
            	<td>:</td>
           	  <td><input name="Count_mes" type="text" size="10" /></td>
            </tr>
        	
        	  
        	<tr>
        	  <td height="50" colspan="4" align="center">
              <input type="submit" name="Submit" value="Submit" />
              <input name="submit2" type="reset" class="formbutton1" id="submit2" value=" Clear " /></td>
       	    </tr>
            <tr>
            <td height="50" colspan="2" align="center">หมายเหตุ</td>
            <td height="50" colspan="2" align="left"><p>กำหนดเลขหมายปลายทางใน text file ได้ไม่เกิน 100 เลขหมาย
              กรุณากรอกข้อมูลให้ครบถ้วนสมบูรณ์ในช่องที่มีเครื่องหมาย <br />
              * กำกับอยู่ 
              ข้อความที่สามารถส่งได้คือ<br />
              :
              ภาษาไทยได้ 70 ตัวอักษร
              ภาษาอังกฤษได้ 140 ตัวอักษร</p></td>
            </tr>
        </table>
        </form>
</body>
</html>