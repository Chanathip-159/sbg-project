<?
session_start();
include("config.php");
include("fn/fn.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
<link href="css/style.css" rel="stylesheet" type="text/css">
<?
$date_now=Date("Y-m-j H:i:s");print_r($_POST);
if(!empty($_SESSION['Admin_ID'])){ //Check Session
	if($_POST['method']=="create"&&$_POST['Admin_Account']){ //Method
		$sql = "SELECT Admin_Account FROM SBG_Admins WHERE Admin_Account='".$_POST['Admin_Account']."'";
		$mssql = mssql_query($sql);
		$check_duplicate = mssql_num_rows($mssql);
		if($check_duplicate==0){
			$sql="INSERT INTO SBG_Admins
				   ([Admin_Account]
				   ,[Admin_Password]
				   ,[Admin_FullName]
				   ,[Admin_Department]
				   ,[Admin_CreateDate])
				VALUES
				   ('".$_POST['Admin_Account']."'
				   ,'".$_POST['Admin_Account']."'
				   ,'".$_POST['Admin_FullName']."'
				   ,'".$_POST['Admin_Department']."'
				   ,'".$date_now."')";
			mssql_query($sql);
			$ext="pg-user";
			header("refresh: 0; url=result.php?nextPage=index&ext=$ext");
		}else{
			$ext="pg-user";
			header("refresh: 0; url=result.php?nextPage=index&ext=$ext&status=repeat");
		}
	}else if($_POST['method']=="edit"&&$_POST['Request_ID']){
		$sql="UPDATE SBG_Admins
			   SET [Admin_FullName] = '".$_POST['Admin_FullName']."'
				  ,[Admin_Department] = '".$_POST['Admin_Department']."'
			 WHERE Admin_ID='".$_POST['Request_ID']."'";
		mssql_query($sql);
		$ext="pg-user";
		header("refresh: 0; url=result.php?nextPage=index&ext=$ext");
	}else if($_POST['method']=="delete"&&$_POST['Request_ID']){
		$sql="DELETE FROM SBG_Admins 
			  WHERE Admin_ID='".$_POST['Request_ID']."'";
		mssql_query($sql);
		$ext="pg-user";
		header("refresh: 0; url=result.php?nextPage=index&ext=$ext");
	}else if($_POST['method']=="reset"&&$_POST['Request_ID']){
		$sql="UPDATE SBG_Admins
			   SET [Admin_Password] = '".md5($_POST['Admin_No'])."'
			 WHERE Admin_ID='".$_POST['Request_ID']."'";
		mssql_query($sql);
		$ext="pg-user";
		header("refresh: 0; url=result.php?nextPage=index&ext=$ext");
	}else{
		$ext="";
		header("refresh: 0; url=result.php?nextPage=index&ext=$ext&status=error");
	}
}else{
	$ext="";
	header("refresh: 0; url=result.php?nextPage=index&ext=$ext&status=error");
}
?>