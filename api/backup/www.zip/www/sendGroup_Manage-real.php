<? 
include("config.php");

if (empty($_POST['Group_ID'])) {
	?>
<SCRIPT language="JavaScript">
alert("Can not get Group ID."); 
window.history.back();
</SCRIPT> 
    <?
}
$Group_ID=$_POST['Group_ID'];
$Group_Method=$_POST['Group_Method'];
$Group_Title=$_POST['Group_Title'];
if(!empty($_POST['Group_TotalFileNumbering'])){
	$total=$_POST['Group_TotalFileNumbering'];
}else{
	$total=$_POST['Group_TotalNumber'];
}
if(empty($_POST['Group_Path'])){
	$Group_Path="";
}else{
	$Group_Path=$_POST['Group_Path'];
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" language="javascript" src="DataTable/js/jquery.js"></script>
<script language="javascript">
function ProcessSMS() {
	var txt = document.getElementById("MsgTxt").value;
	if (checkThai()) { // check thai
		document.getElementById("Counter_SMS").value = Math.ceil(txt.length/140);
	}else{
		document.getElementById("Counter_SMS").value = Math.ceil(txt.length/70);
	}
} 
function checkThai() {
	var txt = document.getElementById("MsgTxt").value;
	for(var i = 0;i < txt.length; i++) {
		if( (txt.charCodeAt(i) > 127) || (txt.charCodeAt(i)==94) || (txt.charCodeAt(i)==92) ) { 
			document.getElementById("LangType").value = "T";
			return false;
		}
	}
	document.getElementById("LangType").value = "E";
	return true;
}
</script>
<table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td valign="top" class="tx_sub_head">Send SMS to <?=$Group_Title?> Group</td>
  </tr>
</table><br />

<form name = "sender" id="sender" action = "send_Query.php" method = "POST">
  <table cellpadding="1" cellspacing="1" bgcolor="<?=$bg_form?>" align="center">
    <tr>
    <td align="center" class="tx_sub_head">Send SMS From</td>
  </tr>
  <tr>
    <td><table width="500" bgcolor="#FFFFFF" align="center">
      <tr>
        <td width="3%">&nbsp;</td>
        <td width="30%">&nbsp;</td>
        <td width="2%">&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td height="25">&nbsp;</td>
        <td>Sender Name</td>
        <td>:</td>
        <?
		$sql = "SELECT [Sender_Name] FROM [VAS].[dbo].[SBG_Senders] WHERE [Customer_ID] = '".$_SESSION["Customer_ID"]."';";
		$mssql = mssql_query($sql);
		$haveRow = false;
		while($data = mssql_fetch_array($mssql)) {
			$haveRow = true;
			$senders[] = $data['Sender_Name'];
		}
		if ($haveRow) {
		?>
        <td><select name="Sender_Name" ><? foreach($senders AS $sender) {?><option><?=$sender?></option><? }?></select></td>
        <?
		} else {
			?><td><input name="Sender_Name" type="text" size="20" /></td><?
		}
		?>
      </tr>
      <tr>
        <td height="25">&nbsp;</td>
        <td>Group Receiver</td>
        <td>:</td>
        <td><?=$Group_Title?></td>
      </tr>
      <tr>
        <td height="25">&nbsp;</td>
        <td>Total of numbering</td>
        <td>:</td>
        <td><?=$total?> Numberings</td>
      </tr>
      <tr>
        <td height="25" valign="top">&nbsp;</td>
        <td valign="top">Message</td>
        <td valign="top">:</td>
        <td><textarea name="MsgTxt" id="MsgTxt" cols="40" rows="5" onKeyUp="ProcessSMS();"></textarea></td>
      </tr>
      <tr>
        <td height="25">&nbsp;</td>
        <td>Number of message</td>
        <td>:</td>
        <td><input name="Counter_SMS" id="Counter_SMS" type="text" size="10" /></td>
      </tr>
      <tr>
        <td height="50" colspan="4" align="center">
        	<input name="SendMode" id="SendMode" type="hidden" value="Group" />
            <input name="Group_ID" id="Group_ID" type="hidden" value="<?=$Group_ID?>"/>
            <? if($Group_Method=="F"){?>
            <input name="Group_Path" id="Group_Path" type="hidden" value="<?=$Group_Path?>"/>
            <? }?>
            <input name="LangType" id="LangType" type="hidden" />
            <input type="submit" name="Submit" value="Send" OnClick="return alert('SMS Delivery may take long time. Please wait.');" />
         </td>
      </tr>
    </table></td>
  </tr>
</table>
</form>
<br /><br />

<script language="javascript">
$("form#sender").submit(function(){
	var formData = new FormData($(this)[0]);
    $.ajax({
        url: $(this).attr('action'),
        type: $(this).attr('method'),
        data: formData,
        async: false,
        crossDomain: true,
        
		success: function (data) {
            alert(data); //alert(data); document.write(data);
        },
		
        cache: false,
        contentType: false,
        processData: false
    });
    return false; //STOP default action
});
</script>
</body>
</html>
