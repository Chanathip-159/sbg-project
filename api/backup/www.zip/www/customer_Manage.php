<?

//ob_start();
//session_start();
include("config.php");
include("fn/fn.php");
///////////////////////////// show errors
ini_set('display_errors', 1); 
error_reporting(E_ALL);
/////////////////////////////
$checkError = ini_get('error_reporting');
error_reporting($checkError  ^ E_NOTICE);
/////////////////////////////
?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css" title="currentStyle">
@import "DataTable/css/demo_page.css";
 @import "DataTable/css/demo_table.css";
</style>
	<script language="javascript" type="text/javascript">
	function ValidateCustomer(form){
	var accountFilter = /^0(1|6|8|9)\d{8}$/; //account regular expression  จากเดิมคือ       0/^0[0-9]{9}$
	var account = document.form.Customer_Account.value; 
	
	var emailFilter = /^.+@.+\..{2,3}$/; //email regular expression
	var email = document.form.Customer_Email.value;
	
	var telFilter = /^0\d{8,9}(,0\d{8,9})*$/; //tel fax regular expression จากเดิมคือ ^\d{9,10}(,\d{9,10})*$
	var tel = document.form.Customer_Telephone.value;
	var fax = document.form.Customer_Fax.value;
	
	var limitAccount = document.form.Customer_PromotionAccount.value;
	var limitMonth = document.form.Customer_PromotionMonth.value;
	
	if (form.Customer_Account.value == ""){
		alert("Customer's account is required!");
		form.Customer_Account.focus();
		return false;
	}
/*	if (!(accountFilter.test(account))){
		alert("Not a valid account, please input only number 10 digits");
		form.Customer_Account.focus();
		return false;
	}  */
	if (form.Sender_Name1.value == ""){
		alert("Sender name is required!");
		form.Sender_Name1.focus();
		return false;
	}
	if (form.Customer_Title.value == ""){
		alert("Customer's title is required!");
		form.Customer_Title.focus();
		return false;
	}  
	if (form.Customer_Contact.value == ""){
		alert("Customer's contact is required!");
		form.Customer_Contact.focus();
		return false;
	}  
	if (form.Customer_Address.value == ""){
		alert("Customer's address is required!");
		form.Customer_Address.focus();
		return false;
	}   
	if (form.Customer_Email.value == ""){
		alert("Customer's e-mail is required!");
		form.Customer_Email.focus();
		return false;
	}
	if (!(emailFilter.test(email))){
		alert("Not a valid e-mail address");
		form.Customer_Email.focus();
		return false;
	}
	if (form.Customer_Telephone.value == ""){
		alert("Customer's telephone is required!");
		form.Customer_Telephone.focus();
		return false;
	}
	if (!(telFilter.test(tel))){
		alert("Not a valid telephone, please input only number 9-10 digits or comma (,) or dash (-)");
		form.Customer_Telephone.focus();
		return false;
	}
	if (form.Customer_Fax.value != ""){
		//alert("Boom!");
		//form.Customer_Fax.focus();
		//return false;
		if (!(telFilter.test(fax))){
		alert("Not a valid fax, please input only number 9-10 digits or comma (,) or dash (-)");
		form.Customer_Fax.focus();
		return false;
		}
		
	}
	
	if (form.Customer_RegisDate.value == ""){
		alert("Customer's registation is required!");
		form.Customer_RegisDate.focus();
		return false;
	}  
	if (form.Customer_ExpireDate.value == ""){
		alert("Customer's expire date is required!");
		form.Customer_ExpireDate.focus();
		return false;
	} 
	if (form.Customer_PromotionAccount.value == ""){
		alert("Customer's limit account is required!");
		form.Customer_PromotionAccount.focus();
		return false;
	} 
	if (Math.ceil(limitAccount)!=Math.floor(limitAccount) || limitAccount<-1){
		alert("Customer's limit account is only integer number, at least -1!");
		form.Customer_PromotionAccount.focus();
		return false;
	}
	if (form.Customer_PromotionMonth.value == ""){
		alert("Customer's limit monthly is required!");
		form.Customer_PromotionMonth.focus();
		return false;
	} 
	if (Math.ceil(limitMonth)!=Math.floor(limitMonth) || limitMonth<-1){
		alert("Customer's limit monthly is only integer number, at least -1!");
		form.Customer_PromotionMonth.focus();
		return false;
	}
	return true;
}
	</script>


<link type="text/css" href="jquery.calendars/humanity.calendars.picker.css" rel="stylesheet"/>

<?
$sql ="SELECT * FROM SBG_Customers ORDER BY Customer_Title";
$mssql = mssql_query($sql);
if(empty($_POST['create'])&&empty($_POST['edit'])&&empty($_POST['delete'])){
?>
    <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
      <form name="formCreateButton" action="<? $PHP_SELF?>" method="post">
      <tr>
        <td valign="top" class="tx_sub_head">Customers</td>
        <td align="right" class="tx_sub_head"><input type="submit" class="button_form" name="create" value="Create Customer" /></td>
      </tr>
      </form>
    </table>
    <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td colspan="2"><div id="demo">
            <table cellpadding="0" cellspacing="0" border="0" class="display" id="example">
              <thead>
                <tr>
                  <th>No.</th>
                  <th>Account</th>
                  <th>Title</th>
                  <th>Regis.</th>
                  <th>Expire</th>
                  <th>Groups</th>
                  <th>Numbers.</th>
                  <th>Per Account</th>
                  <th>Per Month</th>
                  <th>Reset P/W</th>
                  <th>Edit</th>
                  <th>Del.</th>
                </tr>
              </thead>
              <tbody>
              <? $i=0;while($data=mssql_fetch_array($mssql)){ $i++;?>
                <tr class="<?=$bg?>" onMouseOver="this.bgColor='#FFFFFF';" onMouseOut="this.bgColor='<?=$bg?>';">
                  <td align="center"><?=$i?></td>
                  <td><?=$data['Customer_Account']?></td>
                  <td><?=$data['Customer_Title']?></td>
                  <td align="center"><?=substr($data['Customer_RegisDate'],0,11)?></td> <!--เปลี่ยนจาก10เป็น11 เพราะตัดหลังอักษรที่11 เช่น... 31 Oct 2014-->
                  <td align="center"><?=substr($data['Customer_ExpireDate'],0,11)?></td> <!--เปลี่ยนจาก10เป็น11 เพราะตัดหลังอักษรที่11 เช่น... 31 Oct 2014-->
                  <td align="center"><?
                  list($groups)=mssql_fetch_array(mssql_query("SELECT COUNT(Group_ID) FROM SBG_Groups WHERE Customer_ID='".$data['Customer_ID']."'"));
					  echo number_format($groups,0);
				  ?></td>
                  <td align="center"><?
                  list($numberings_system)=mssql_fetch_array(mssql_query("SELECT COUNT(Number_ID) FROM SBG_Groups g LEFT JOIN SBG_Numberings n ON g.Group_ID=n.Group_ID WHERE Customer_ID='".$data['Customer_ID']."'"));
                  list($numberings_file)=mssql_fetch_array(mssql_query("SELECT SUM(Group_TotalFileNumbering) FROM SBG_Groups WHERE Customer_ID='".$data['Customer_ID']."' AND Group_Method='F'"));
				  $numberings = $numberings_system + $numberings_file;
					  echo number_format($numberings,0);
				  ?></td>
                  <td align="center">
				  <?
                  if($data['Customer_PromotionAccount']==-1){
					  echo "No limit";
				  }else{
					  echo number_format($data['Customer_PromotionAccount'],0);
				  }
				  ?>
                  </td>
                  <td align="center">
				  <?
                  if($data['Customer_PromotionMonth']==-1){
					  echo "No limit";
				  }else{
					  echo number_format($data['Customer_PromotionMonth'],0);
				  }
				  ?>
                  </td>
                  <form name="formResetButton" action="customer_Query.php" method="post">
                  <td align="center">
                  <input type="hidden" name="Customer_No" value="<?=$data['Customer_Account']?>" />
                  <input type="hidden" name="Customer_Account" value="<?=md5(md5($data['Customer_Account']))?>" />
                  <input type="hidden" name="Request_ID" value="<?=$data['Customer_ID']?>" />
                  <input type="hidden" name="method" value="reset" />
                  <input type="image" src="image/pw.png" name="reset" value="reset" onclick="return confirm('Are you sure you want to reset password?')" />
                  </td>
                  </form>
                  <form name="formEditButton" action="<? $PHP_SELF?>" method="post">
                  <td align="center">
                  <input type="hidden" name="Customer_Account" value="<?=md5(md5($data['Customer_Account']))?>" />
                  <input type="hidden" name="Request_ID" value="<?=$data['Customer_ID']?>" />
                  <input type="hidden" name="edit" value="<?=$data['Customer_ID']?>" />
                  <input type="image" src="image/edit.gif" name="edit" value="Edit" />
                  </td>
                  </form>
                  <form name="formDeleteButton" action="customer_Query.php" method="post">
                  <td align="center">
                  <input type="hidden" name="Customer_Account" value="<?=md5(md5($data['Customer_Account']))?>" />
                  <input type="hidden" name="Request_ID" value="<?=$data['Customer_ID']?>" />
                  <input type="hidden" name="method" value="delete" />
                  <input type="image" src="image/delete.gif" name="delete" value="Delete" onclick="return confirm('Are you sure you want to delete this?')" />
                  </td>
                  </form>
                </tr>
               <? }?>
            </table>
          </div>
          <div class="spacer"></div></td>
      </tr>
    </table>
	<? }else{echo "<br><br>";
		if(!empty($_POST['create'])){?>
    	<form name="form" action="customer_Query.php" method="post" onsubmit="return ValidateCustomer(this)">
    	<table cellpadding="1" cellspacing="1" bgcolor="<?=$bg_form?>" align="center"><tr>
    	<td align="center" class="tx_sub_head">Customers Create Form</td></tr><tr><td>
        <table width="600" bgcolor="#FFFFFF">
        	<tr>
        	  <td width="3%">&nbsp;</td>
        	  <td width="25%">&nbsp;</td>
        	  <td width="2%">&nbsp;</td>
        	  <td>&nbsp;</td>
      	    </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
        	  <td>Account</td>
        	  <td>:</td>
        	  <td><input name="Customer_Account" type="text" size="20" maxlength="10" />
        	  * 
        	    Customer's number (0861234567)</td>

				
				
				
      	  </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
        	  <td>Sender name</td>
        	  <td>:</td>
        	  <td>
				<div id='TextBoxesGroup'> 
					<div id="TextBoxDiv1">
					<input name="Sender_Name1" type="text" id="Sender_Name1" size="20" />
					* Min=1, Max=10&nbsp;         
					<img src='image/add.png' id='addButton'>&nbsp;Add&nbsp;&nbsp;<img src='image/remove.png' id='removeButton'>&nbsp;Remove
					</div>
				</div>	
			  </td>		  
      	  </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
           	  <td>Title</td>
            	<td>:</td>
            	<td><input name="Customer_Title" type="text" size="50" />
            	*</td>

				
				
				
            </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
           	  <td>Contact</td>
            	<td>:</td>
            	<td><input name="Customer_Contact" type="text" size="50" />
            	*</td>
            </tr>
        	<tr>
        	  <td height="25" valign="top">&nbsp;</td>
           	  <td valign="top">Address</td>
            	<td valign="top">:</td>
            	<td><textarea name="Customer_Address" cols="40" rows="5"></textarea>
            	*</td>
            </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
           	  <td>Email</td>
            	<td>:</td>
           	  <td><input name="Customer_Email" type="text" size="40" />
           	  *</td>
            </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
           	  <td>Telephone</td>
            	<td>:</td>
            	<td><input name="Customer_Telephone" type="text" size="40" />
            	*</td>
            </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
           	  <td>Fax</td>
            	<td>:</td>
            	<td><input name="Customer_Fax" type="text" size="40" /></td>
            </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
        	  <td>Registation Date</td>
        	  <td>:</td>
        	  <td><input name="Customer_RegisDate" id="RegisDate" type="text" size="9" maxlength="20" class="tahoma12Normal" readonly>
        	  *</td>
      	  </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
        	  <td>Expire Date</td>
        	  <td>:</td>
        	  <td><input name="Customer_ExpireDate" id="ExpireDate" type="text" size="9" maxlength="20" class="tahoma12Normal" readonly>
        	  *</td>
      	  </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
        	  <td>Limit Account</td>
        	  <td>:</td>
        	  <td><input name="Customer_PromotionAccount" type="text" size="20" />
        	  *
        	  No limit = -1</td>
      	  </tr>
		  <tr>
        	  <td height="25">&nbsp;</td>
        	  <td>Limit Monthly</td>
        	  <td>:</td>
        	  <td><input name="Customer_PromotionMonth" type="text" size="20" />
        	  *
No limit = -1</td>
      	  </tr>
		  <tr>
			  <td height="25">&nbsp;</td>
        	  <td>Daily Report</td>
        	  <td>:</td>
        	  <td><input name="Customer_DR" type="radio" value="1">Yes&nbsp;&nbsp;<input name="Customer_DR" type="radio" value="0" checked>No</td>
		  </tr>
		  <tr>
        	  <td height="25">&nbsp;</td>
           	  <td>Remark</td>
            	<td>:</td>
           	  <td><textarea name="Customer_Remark" cols="40" rows="5"></textarea></td>
            </tr>
        	<tr>
        	  <td height="50" colspan="4" align="center"><input type="hidden" name="method" value="create" /><input type="submit" name="Submit" value="Submit" />
       	      &nbsp;
       	      <input type="reset" name="Reset" id="button" value="Reset" /></td>
       	    </tr>
        </table>
        </td></tr></table>
        </form>
    <? 
	}else if(!empty($_POST['edit'])){
		$sql_1=mssql_query("SELECT * From SBG_Customers where Customer_ID ='".$_POST['Request_ID']."'");
		$sql_2=mssql_query("SELECT * From SBG_Senders where Customer_ID ='".$_POST['Request_ID']."' ORDER BY Sender_ID ASC");
		$edit_1=mssql_fetch_array($sql_1);
		list($Last_SenderID)= mssql_fetch_array(mssql_query("SELECT MAX(Sender_ID) FROM SBG_Senders"));
		
	?>
    	<form name="form" action="customer_Query.php" method="post" onsubmit="return ValidateCustomer(this)">
    	<table cellpadding="1" cellspacing="1" bgcolor="<?=$bg_form?>" align="center"><tr>
    	<td align="center" class="tx_sub_head">Customers Edit Form</td></tr><tr><td>
        <table width="600" align="center" bgcolor="#FFFFFF">
          <tr>
            <td width="3%">&nbsp;</td>
            <td width="25%">&nbsp;</td>
            <td width="2%">&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td height="25">&nbsp;</td>
            <td>Account</td>
            <td>:</td>
            <td><?=$edit_1['Customer_Account']?></td>
          </tr>
          <tr>
            <td height="25">&nbsp;</td>
            <td>Sender name</td>
            <td>:</td>
			<td></form><div id='BigDiv'>
<?
            
			$row = mssql_num_rows($sql_2);
			
			
			if($row!=0){
?>
			
					<div id="TextBoxDiv">
<?			
				$id=0;
				while($edit_2=mssql_fetch_array($sql_2)){
?>
				<form name="form<?=$id?>" action="customer_Query.php" method="post" target="iframe_target" onsubmit="return ValidateCustomer(this)">
				
				<iframe id="iframe_target" name="iframe_target" src="#" style="width:0;height:0;border:0px solid #fff;"></iframe>
				<span><input name="Sender_Name" type="text" id="Sender_Name" size="20" value="<?=$edit_2['Sender_Name']?>"/>*
								
        	    
				<input type="hidden" name="Request_ID" value="<?=$edit_1['Customer_ID']?>" /> <!--เผื่อใช้-->
				<input type="hidden" name="Request_Sender" value="<?=$edit_2['Sender_ID']?>" />
				<input type="hidden" name="method" value="remove" />
				<input type="image" src="image/cross.jpg" name="remove" onclick="return confirm('Are you sure you want to remove <?=$edit_2['Sender_Name']?> ?')" /></span><br>
				</form>			
				
<?				$id++;
				}
			}
			

?>			
		  
				</div>
					  <div>
		  
		  <form name="form" action="customer_Query.php" method="post" onsubmit="return ValidateCustomer(this)">
		  
			</td>
		  </tr>
		    <tr>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td><img src='image/add.png' id='addButton1'>&nbsp;Add&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src='image/remove.png' id='removeButton1'>&nbsp;Remove</td>
			</tr> 
        	<tr>
        	  <td height="25">&nbsp;</td>
           	  <td>Title</td>
            	<td>:</td>
            	<td><input name="Customer_Title" type="text" size="50" value="<?=$edit_1['Customer_Title']?>" />
            	*</td>
            </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
           	  <td>Contact</td>
            	<td>:</td>
            	<td><input name="Customer_Contact" type="text" size="50" value="<?=$edit_1['Customer_Contact']?>" />
            	*</td>
            </tr>
        	<tr>
        	  <td height="25" valign="top">&nbsp;</td>
           	  <td valign="top">Address</td>
            	<td valign="top">:</td>
            	<td><textarea name="Customer_Address" cols="40" rows="5"><?=$edit_1['Customer_Address']?></textarea>
            	*</td>
            </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
           	  <td>Email</td>
            	<td>:</td>
           	  <td><input name="Customer_Email" type="text" size="40" value="<?=$edit_1['Customer_Email']?>" />
           	  *</td>
            </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
           	  <td>Telephone</td>
            	<td>:</td>
            	<td><input name="Customer_Telephone" type="text" size="40" value="<?=$edit_1['Customer_Telephone']?>" />
            	*</td>
            </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
           	  <td>Fax</td>
            	<td>:</td>
            	<td><input name="Customer_Fax" type="text" size="40" value="<?=$edit_1['Customer_Fax']?>" />
            	*</td>
            </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
        	  <td>Registation Date</td>
        	  <td>:</td>
        	  <td><input name="Customer_RegisDate" id="RegisDate" type="text" size="12" maxlength="20" class="tahoma12Normal" readonly value="<?=substr($edit_1['Customer_RegisDate'],0,11)?>" /> <!--เปลี่ยนจาก10เป็น11 เพราะตัดหลังอักษรที่11 เช่น... 31 Oct 2014-->
        	  *</td>
      	  </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
        	  <td>Expire Date</td>
        	  <td>:</td>
        	  <td><input name="Customer_ExpireDate" id="ExpireDate" type="text" size="12" maxlength="20" class="tahoma12Normal" readonly value="<?=substr($edit_1['Customer_ExpireDate'],0,11)?>" /> <!--เปลี่ยนจาก10เป็น11 เพราะตัดหลังอักษรที่11 เช่น... 31 Oct 2014-->
        	  *</td>
      	  </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
        	  <td>Limit Account</td>
        	  <td>:</td>
        	  <td><input name="Customer_PromotionAccount" type="text" value="<?=$edit_1['Customer_PromotionAccount']?>" size="20" />
        	  *
No limit = -1</td>
      	  </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
        	  <td>Limit Monthly</td>
        	  <td>:</td>
        	  <td><input name="Customer_PromotionMonth" type="text" value="<?=$edit_1['Customer_PromotionMonth']?>" size="20" />
        	  *
No limit = -1</td>
      	  </tr>
		  <tr>
			  <td height="25">&nbsp;</td>
        	  <td>Daily Report</td>
        	  <td>:</td>
        	  <td><input name="Customer_DR" type="radio" value="1" <?php if ($edit_1['Customer_DR']==1) echo "checked";?>>Yes&nbsp;&nbsp;<input name="Customer_DR" type="radio" value="0" <?php if (!isset($edit_1['Customer_DR']) || $edit_1['Customer_DR']==0) echo "checked";?>>No</td>
		  </tr>		  
        	<tr>
        	  <td height="25">&nbsp;</td>
        	  <td>Current usage</td>
        	  <td>:</td>
        	  <td><?=number_format($edit_1['Customer_AllCurrentUsage'],0)?></td>
      	  </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
        	  <td>Create Date</td>
        	  <td>:</td>
        	  <td><?=substr($edit_1['Customer_CreateDate'],0,10)?></td>
      	  </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
        	  <td>Revise Date</td>
        	  <td>:</td>
        	  <td><?=substr($edit_1['Customer_UpDate'],0,10)?></td>
      	  </tr>
		  <tr>
        	  <td height="25">&nbsp;</td>
           	  <td>Remark</td>
            	<td>:</td>
            	<td><textarea name="Customer_Remark" cols="40" rows="5"><?=$edit_1['Customer_Remark']?></textarea></td>
            </tr>
        	<tr>
        	  <td height="50" colspan="4" align="center"><input type="hidden" name="Request_ID" value="<?=$edit_1['Customer_ID']?>" />
        	    <input type="hidden" name="method" value="edit" />
        	    <input type="submit" name="Submit" value="Submit" />
        	    &nbsp;
                <input type="reset" name="button" id="button2" value="Reset" /></td>
      	  </tr>
        </table>
        </td></tr></table>	
        </form>
<? 		}
		echo "<br><br>";
	}

	echo '<script type="text/javascript">';
	echo "var row = '$row';"; // ส่งค่า $data จาก PHP ไปยังตัวแปร data ของ Javascript
	echo "var last_SenderID = '$Last_SenderID';";
	echo '</script>';
?>
<script>
//alert(last_SenderID); //test ตัวแปร
</script>	
<script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="js/jquery.dataTables.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.min.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.plus.min.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.picker.min.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.thai.min.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.thai-th.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.picker-th.js"></script>
<script type="text/javascript" charset="utf-8">
	$.fn.dataTableExt.oApi.fnGetHiddenTrNodes = function ( oSettings ){
		var anNodes = this.oApi._fnGetTrNodes( oSettings );
		var anDisplay = $('tbody tr', oSettings.nTable);
		for ( var i=0 ; i<anDisplay.length ; i++ ){
			var iIndex = jQuery.inArray( anDisplay[i], anNodes );
			if ( iIndex != -1 ){
				anNodes.splice( iIndex, 1 );
			}
		}
		return anNodes;
	}
	var oTable;
	var counter_a;
	var counter_b;
	var c=0;
	$(document).ready(function() {
		var oTable = $('#example').dataTable();
		var b=parseInt(row);
		var i=1;
		var a=b+i;
		var counter_b = b+i;
		$('#button').click( function () {
			var nHidden = oTable.fnGetHiddenTrNodes( );
			alert( nHidden.length +' nodes were returned' );
		} );
		$('#RegisDate').calendarsPicker({ minDate: "-12M -0D", maxDate:0, dateFormat:"yyyy-mm-dd", calendar: $.calendars.instance('thai','th')});
		$('#ExpireDate').calendarsPicker({ minDate: "-0D", maxDate:"10Y -0M -0D", dateFormat:"yyyy-mm-dd", calendar: $.calendars.instance('thai','th')});
	
		var counter_a = 2;
		$('#addButton').click(function () {
			if(counter_a>10){
				alert("Only 10 Sender Names allow");
				return false;
			}   
		var newTextBoxDiv = $(document.createElement('div')).attr("id", 'TextBoxDiv' + counter_a);
		newTextBoxDiv.after().html('<input name="Sender_Name' + counter_a + '" type="text" id="Sender_Name' + counter_a + '" size="20" />');
		newTextBoxDiv.appendTo("#TextBoxesGroup");
		counter_a++;
		});
		$('#removeButton').click(function () {
			if(counter_a==2){
				alert("Must has at least 1 Sender Name");
				return false;
			}   
		counter_a--;
		$("#TextBoxDiv" + counter_a).remove();
		});
		$('#addButton1').click(function () {
			if(counter_b>10){
				alert("Only 10 Sender Names allow");
				return false;
			}
			
				var newTextBoxDiv = $(document.createElement('div')).attr("id", 'TextBoxDiv' + counter_b);
				newTextBoxDiv.after().html('<form name="form" action="customer_Query.php" target="iframe_target" method="post" onsubmit="return ValidateCustomer(this)"><iframe id="iframe_target" name="iframe_target" src="#" style="width:0;height:0;border:0px solid #fff;"></iframe><input name="Sender_Name" type="text" id="Sender_Name" size="20" />&nbsp;&nbsp;&nbsp;<input type="hidden" name="Request_ID" value="<?=$edit_1['Customer_ID']?>" /><input type="hidden" name="method" value="add" /><input type="image" src="image/save.jpg" name="add" /></form>');
				newTextBoxDiv.appendTo("#BigDiv");
				counter_b++;
				c++;
			
		});
		$('#removeButton1').click(function () {
			if(c==0){
				alert("No Textbox to remove");
				return false;
			}else{   
		counter_b--;
		$("#TextBoxDiv" + counter_b).remove(); 
		c--;
		}
		});
	});
</script>
