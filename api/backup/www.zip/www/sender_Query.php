<?
//have problem in line: 21 and 56, "sender name".
ob_start();
session_start();
include("config.php");
//include("fn/fn.php");
///////////////////////////// show errors
ini_set('display_errors', 1); 
error_reporting(E_ALL);
/////////////////////////////
?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
<link href="css/style.css" rel="stylesheet" type="text/css">
<?

if($_POST['method']=="remove"&&$_POST['Request_Sender']){
$sql="DELETE FROM SBG_Senders WHERE Sender_ID='".$_POST['Request_Sender']."'";
mssql_query($sql);
		
		$ext="pg-customer";
		header("refresh: 0; url=result.php?nextPage=index&ext=$ext");
		}
ob_end_flush();		
?>		