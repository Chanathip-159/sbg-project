<?

		$hostname1 = "10.99.4.170\MSSQLSERVER02"; // ชื่อ Host
        $usename1 = "smsgw"; // username เข้าฐานข้อมูล
        $password1 = "P@ssDB"; // password เข้าฐานข้อมูล
        $database1 = "SMSGW_VAS"; // ฐานข้อมูล
        $conn1 = mssql_connect($hostname1,$usename1,$password1,$database1) or die ("ติดต่อฐานข้อมูลไม่ได้");
        //mssql_query("SET NAMES UTF8",$conn1);
        mssql_select_db($database1) or die ("เลือกฐานข้อมูลไม่ได้");

?>