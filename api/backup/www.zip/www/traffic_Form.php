<? include("config.php");?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<script type="text/javascript" language="javascript" src="/DataTable/js/jquery.js"></script>
<?
$con2=mssql_connect("10.100.143.100","sa","V@5my") or die("CAN'T CONNECT DATABASE SERVER");###
mssql_select_db("SMS",$con2) or die("CAN'T CONNECT DATABASE  SMS "); ####################
?>
<table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
  <form action="<? $PHP_SELF?>" method="post" name="formCreateButton" id="formCreateButton">
    <tr>
      <td valign="top" class="tx_sub_head">Buffer</td>
    </tr>
  </form>
</table>
<br />
<?
$sql = "SELECT COUNT(*) AS total FROM [SMS].[dbo].[SBG_pend]";
$mssql = mssql_query($sql);
$pend=mssql_fetch_array($mssql);

$sql = "SELECT COUNT(*) AS total FROM [SMS].[dbo].[SBG_send]";
$mssql = mssql_query($sql);
$send=mssql_fetch_array($mssql);

$sql = "SELECT COUNT(*) AS total FROM [SMS].[dbo].[SBG_resp]";
$mssql = mssql_query($sql);
$resp=mssql_fetch_array($mssql);

$sql = "SELECT COUNT(*) AS total FROM [SMS].[dbo].[SBG_redr]";
$mssql = mssql_query($sql);
$redr=mssql_fetch_array($mssql);
?>
<table width="400" border="0" align="center" cellpadding="1" cellspacing="1" bgcolor="<?=$bg_tableBorder?>">
  <tr>
    <td align="center">Pending</td>
    <td align="center">Send</td>
    <td align="center">Response</td>
    <td align="center">Delivery</td>
  </tr>
  <tr>
    <td align="center" bgcolor="<?=$bg_tableOdd;?>"><?=$pend['total'];?></td>
    <td align="center" bgcolor="<?=$bg_tableOdd;?>"><?=$send['total'];?></td>
    <td align="center" bgcolor="<?=$bg_tableOdd;?>"><?=$resp['total'];?></td>
    <td align="center" bgcolor="<?=$bg_tableOdd;?>"><?=$redr['total'];?></td>
  </tr>
</table>


<table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
  <form action="<? $PHP_SELF?>" method="post" name="formCreateButton" id="formCreateButton">
    <tr>
      <td valign="top" class="tx_sub_head">Traffic (last 24 hours)</td>
    </tr>
  </form>
</table>
<br />
<table width="400" border="0" align="center" cellpadding="1" cellspacing="1" bgcolor="<?=$bg_tableBorder?>">
  <tr>
    <td align="center">No.</td>
    <td align="center">Date</td>
    <td align="center">Time</td>
    <td align="center">SMS</td>
  </tr>
  <?
	  $interval = 15; // Minute
	   $startTime = strtotime("-1 day");
	   $startTime = (floor($startTime/($interval*60))*($interval*60))+($interval*60); // floor every $interval
	   $stopTime = time();
	   $stopTime = floor($stopTime/($interval*60))*($interval*60); // floor every $interval
	   //$startDate = date("Y-m-d H:i:s", $startTime);
	   $startDate = date("m/d/Y H:i:s", $startTime);
	   $monthDate = date("m", $startTime);
	   for($i=$startTime;$i<=$stopTime;$i+=($interval*60)) {
		   $allData[date("Y-m-d", $i)][" ".(int) date("H", $i)][" ".(int) date("i", $i)] = 0;
	   }
	   $sql = "
DECLARE @interval INT 
SET @interval = $interval
SELECT 
	DATEPART(yy, incoming_datetime) AS [Year]
	, DATEPART(mm, incoming_datetime) AS [Month]
	, DATEPART(dd, incoming_datetime) AS [Day]
	, DATEPART(hh, incoming_datetime) AS [Hour]
	, DATEPART(mi, incoming_datetime)/@interval*@interval AS [Minute]
	, COUNT(*) AS [Results]
FROM [SMSCDR$monthDate]
WHERE [incoming_datetime] >= GETDATE()-1 AND [service_type] = 'SBG'
GROUP BY 
	DATEPART(yy, incoming_datetime)
	, DATEPART(mm, incoming_datetime)
	, DATEPART(dd, incoming_datetime)
	, DATEPART(hh, incoming_datetime)
	, DATEPART(mi, incoming_datetime)/@interval*@interval";//*/
	   $mssql = mssql_query($sql);
	   while($row=mssql_fetch_array($mssql)) {
		   ///print_r($row);
		   if ($row['Month']<10) $month = "0".$row['Month']; else $month = $row['Month'];
		   if ($row['Day']<10) $day = "0".$row['Day']; else $day = $row['Day'];
		   
		   $allData[$row['Year']."-".$month."-".$day][" ".(int) $row['Hour']][" ".(int) $row['Minute']] = $row['Results'];
	   }
	   $bgMark = false;
	   $allData = array_reverse($allData);
	   $no = 0;
	   $total = 0;
	   foreach($allData as $date => $hours) {
		   $hours = array_reverse($hours);
		   foreach($hours as $hour => $minutes) {
			   $minutes = array_reverse($minutes);
			   if ($bgMark) $bgMark = false; else $bgMark = true;
			   foreach($minutes as $minute => $sms) {
				   $no++;
				   $total=$total+$sms;
				   if ($bgMark) $bgColor="bgcolor=\"".$bg_tableOdd."\""; else $bgColor="bgcolor=\"".$bg_tableEven."\"";
	  ?>
  <tr>
    <td align="center" <?=$bgColor?>><?=$no?></td>
    <td align="center" <?=$bgColor?>><?=$date?></td>
    <td align="center" <?=$bgColor?>><? if($hour<10) echo "0".trim($hour); else echo $hour;?>
      :
      <? if ($minute == 0) echo " 00"; else echo $minute;?>
      : 00</td>
    <td align="right" <?=$bgColor?>><?=number_format($sms,0)?>&nbsp;</td>
  </tr>
  <? }}}?>
  <tr>
    <td colspan="3" align="center">Total</td>
    <td align="right"><?=number_format($total,0)?>&nbsp;</td>
  </tr>
</table>