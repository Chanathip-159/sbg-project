<?
session_start();
include("config.php");
include("fn/fn.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
<link href="css/style.css" rel="stylesheet" type="text/css">
<?
$date_now=Date("Y-m-j H:i:s");
if(!empty($_SESSION['Customer_ID'])){ //Check Session
	if($_POST['method']=="create"&&$_POST['Number_No']&&$_POST['Rows']<100){ //Method
		$sql = "SELECT Number_No FROM SBG_Numberings WHERE Number_No='".$_POST['Number_No']."' AND Group_ID='".$_POST['Group_ID']."'";
		$mssql = mssql_query($sql);
		$check_duplicate = mssql_num_rows($mssql);
		if($check_duplicate==0){
			$sql="INSERT INTO SBG_Numberings
				   ([Number_No]
				   ,[Number_CreateDate]
				   ,[Group_ID])
				VALUES
				   ('".$_POST['Number_No']."'
				   ,'".$date_now."'
				   ,'".$_POST['Group_ID']."')";
			mssql_query($sql);
			$ext="pg-number,Group_ID-".$_POST['Group_ID'];
			header("refresh: 0; url=result.php?nextPage=index&ext=$ext");
		}else{
			$ext="pg-number,Group_ID-".$_POST['Group_ID'];
			header("refresh: 0; url=result.php?nextPage=index&ext=$ext&status=repeat");
		}
	}else if($_POST['method']=="edit"&&$_POST['Number_ID']){
		$status="";
		$sql = "SELECT Number_No FROM SBG_Numberings WHERE Number_No='".$_POST['Number_No']."' AND Group_ID='".$_POST['Group_ID']."'";
		$mssql = mssql_query($sql);
		$check_duplicate = mssql_num_rows($mssql);
		if($check_duplicate==0){
			$sql="UPDATE SBG_Numberings
				   SET [Number_No] = '".$_POST['Number_No']."'
				 WHERE Number_ID='".$_POST['Number_ID']."'";
			mssql_query($sql);
		}else{
			$ext="pg-number,Group_ID-".$_POST['Group_ID'];
			$status="&status=repeat";
		}
		$ext="pg-number,Group_ID-".$_POST['Group_ID'];
		header("refresh: 0; url=result.php?nextPage=index&ext=$ext$status");
	}else if($_POST['method']=="delete"&&$_POST['Number_ID']){
		$sql="DELETE FROM SBG_Numberings WHERE Number_ID='".$_POST['Number_ID']."'";
		mssql_query($sql);
		$ext="pg-number,Group_ID-".$_POST['Group_ID'];
		header("refresh: 0; url=result.php?nextPage=index&ext=$ext");
	}else{
		$ext="";
		header("refresh: 0; url=result.php?nextPage=index&ext=$ext&status=error");
	}
}else{
	$ext="";
	header("refresh: 0; url=result.php?nextPage=index&ext=$ext&status=error");
}
?>