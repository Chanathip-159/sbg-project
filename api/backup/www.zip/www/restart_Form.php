<? include("config.php");?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<script type="text/javascript" language="javascript" src="/DataTable/js/jquery.js"></script>
<br />
<br />
<form name="myForm" id="myForm" action="http://10.100.143.142/api/bulk.web.service.restart.php" method="post">
  <table cellpadding="1" cellspacing="1" bgcolor="<?=$bg_form?>" align="center">
    <tr>
      <td align="center" class="tx_sub_head">Restart Form</td>
    </tr>
    <tr>
      <td><table width="500" align="center" bgcolor="#FFFFFF">
          <tr>
            <td height="50" align="center"><p>&nbsp;</p>
              <p>The restartation is stop service for approximately 10 seconds.</p>
              <p>&nbsp;</p>
              <p>
                <input type="hidden" name="ssh" value="bulk.web.service.restart" />
                <input type="submit" name="Submit" value="Restart service" />
            </p>
            <p>&nbsp;</p></td>
          </tr>
        </table></td>
    </tr>
  </table>
</form>
<script language="javascript" type="application/javascript">
$("form#myForm").submit(function(){
	if (confirm("Are you sure you want to restart service?")) {
		var formData = new FormData($(this)[0]);
		$.ajax({
			url: $(this).attr('action'),
			type: $(this).attr('method'),
			data: formData,
			async: false,
			crossDomain: true,
			success: function (data) {
				alert(data);
			},
			cache: false,
			contentType: false,
			processData: false
		});
	}
    return false; //STOP default action
});
//*/
</script>
