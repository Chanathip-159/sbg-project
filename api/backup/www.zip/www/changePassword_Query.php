<?
session_start();
include("config.php");
include("fn/fn.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
<link href="css/style.css" rel="stylesheet" type="text/css">
<?
$date_now=Date("Y-m-j H:i:s");
if(!empty($_SESSION['Customer_ID'])){ //Check Session
	if($_POST['method']=="edit"&&$_SESSION['Customer_ID']){
		$sql="UPDATE SBG_Customers
			   SET [Customer_Password] = '".md5($_POST['New_Password'])."'
			 WHERE Customer_ID='".$_SESSION['Customer_ID']."'";
		mssql_query($sql);
		$ext="pg-change";
		header("refresh: 0; url=result.php?nextPage=index&ext=$ext");
	}else{
		$ext="";
		header("refresh: 0; url=result.php?nextPage=index&ext=$ext&status=error");
	}
}else if(!empty($_SESSION['Admin_ID'])){
	if($_POST['method']=="edit"&&$_SESSION['Admin_ID']){
		$sql="UPDATE SBG_Admins
			   SET [Admin_Password] = '".md5($_POST['New_Password'])."'
			 WHERE Admin_ID='".$_SESSION['Admin_ID']."'";
		mssql_query($sql);
		$ext="pg-change";
		header("refresh: 0; url=result.php?nextPage=index&ext=$ext");
	}else{
		$ext="";
		header("refresh: 0; url=result.php?nextPage=index&ext=$ext&status=error");
	}
}else{
	$ext="";
	header("refresh: 0; url=result.php?nextPage=index&ext=$ext&status=error");
}
?>