<?

ob_start();
session_start();
include("config.php");
include("fn/fn.php");
///////////////////////////// show errors
ini_set('display_errors', 1); 
error_reporting(E_ALL);
/////////////////////////////
$checkError = ini_get('error_reporting');
error_reporting($checkError  ^ E_NOTICE);
/////////////////////////////
?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" />
<link href="css/style.css" rel="stylesheet" type="text/css">
<?

$date_now=Date("Y-m-j H:i:s");
$a=array($_POST['Sender_Name1'],$_POST['Sender_Name2'],$_POST['Sender_Name3'],$_POST['Sender_Name4'],$_POST['Sender_Name5']);

if(!empty($_SESSION['Admin_ID'])){ //Check Session
	if($_POST['method']=="create"&&$_POST['Customer_Account']){ //Method
		$sql = "SELECT Customer_Account FROM SBG_Customers WHERE Customer_Account='".$_POST['Customer_Account']."'";
		$mssql = mssql_query($sql);
		$check_CustomerAccount_duplicate = mssql_num_rows($mssql);
		if($check_CustomerAccount_duplicate==0){
			$sql = "SELECT Customer_Account FROM SBG_Senders s INNER JOIN SBG_Customers c ON s.Customer_ID=c.Customer_ID WHERE Customer_Account='".$_POST['Customer_Account']."' AND Sender_Name='".$_POST['Sender_Name']."'"; //งง
			$mssql = mssql_query($sql);
			$check_SenderName_duplicate = mssql_num_rows($mssql);
			if($check_SenderName_duplicate==0){
				$sql="INSERT INTO SBG_Customers
					   ([Customer_Account]
					   ,[Customer_Password]
					   ,[Customer_Title]
					   ,[Customer_Contact]
					   ,[Customer_Address]
					   ,[Customer_Email]
					   ,[Customer_Telephone]
					   ,[Customer_Fax]
					   ,[Customer_CreateDate]
					   ,[Customer_RegisDate]
					   ,[Customer_ExpireDate]
					   ,[Customer_PromotionAccount]
					   ,[Customer_PromotionMonth]
					   ,[Customer_Connected]
					   ,[Customer_DR]
					   ,[Customer_Remark])
					VALUES
					   ('".$_POST['Customer_Account']."'
					   ,'".md5(substr($_POST['Customer_Account'],-4,4))."'
					   ,'".$_POST['Customer_Title']."'
					   ,'".$_POST['Customer_Contact']."'
					   ,'".$_POST['Customer_Address']."'
					   ,'".$_POST['Customer_Email']."'
					   ,'".$_POST['Customer_Telephone']."'
					   ,'".$_POST['Customer_Fax']."'
					   ,'".$date_now."'
					   ,'".$_POST['Customer_RegisDate']."'
					   ,'".$_POST['Customer_ExpireDate']."'
					   ,'".$_POST['Customer_PromotionAccount']."'
					   ,'".$_POST['Customer_PromotionMonth']."'
					   ,'0'
					   ,'".$_POST['Customer_DR']."'
					   ,'".$_POST['Customer_Remark']."')";
				mssql_query($sql);
				list($Last_CustomerID)= mssql_fetch_array(mssql_query("SELECT MAX(Customer_ID) FROM SBG_Customers"));
				
				/*
				$strSQL="INSERT INTO SBG_Senders (Sender_Name, Customer_ID) ";
				$strSQL.="VALUES ('".$_POST['Sender_Name1']."','".$Last_CustomerID."') ";
					mssql_query($strSQL); //edit Sender_Name1 //test "$strSQL."
					if(!empty($_POST['Sender_Name2']))
					{
						mssql_query("INSERT INTO SBG_Senders (Sender_Name, Customer_ID) VALUES ('".$_POST['Sender_Name2']."','".$Last_CustomerID."')");
						if(!empty($_POST['Sender_Name3']))
						{
							mssql_query("INSERT INTO SBG_Senders (Sender_Name, Customer_ID) VALUES ('".$_POST['Sender_Name3']."','".$Last_CustomerID."')");
							if(!empty($_POST['Sender_Name4']))
							{
								mssql_query("INSERT INTO SBG_Senders (Sender_Name, Customer_ID) VALUES ('".$_POST['Sender_Name4']."','".$Last_CustomerID."')");
								if(!empty($_POST['Sender_Name5']))
								{
									mssql_query("INSERT INTO SBG_Senders (Sender_Name, Customer_ID) VALUES ('".$_POST['Sender_Name5']."','".$Last_CustomerID."')");
								}//else{}
							}//else{}
						}//else{}
					}//else{}
				*/
				
				

					for($i=0;$i<=4;$i++){
						if(!empty($a[$i])){
							$strSQL = "INSERT INTO SBG_Senders (Sender_Name, Customer_ID) VALUES ('".$a[$i]."','".$Last_CustomerID."')";
							mssql_query($strSQL);
						}	
					}
					
				
					
				$ext="pg-customer";
				header("refresh: 0; url=result.php?nextPage=index&ext=$ext");
			}else{
				$ext="pg-customer";
				header("refresh: 0; url=result.php?nextPage=index&ext=$ext&status=repeat");
			}
		}else{
			$ext="pg-customer";
			header("refresh: 0; url=result.php?nextPage=index&ext=$ext&status=repeat");
		}
	}else if($_POST['method']=="edit"&&$_POST['Request_ID']){
	
			
		$sql="UPDATE SBG_Customers
			   SET [Customer_Title] = '".$_POST['Customer_Title']."'
				  ,[Customer_Contact] = '".$_POST['Customer_Contact']."'
				  ,[Customer_Address] = '".$_POST['Customer_Address']."'
				  ,[Customer_Telephone] = '".$_POST['Customer_Telephone']."'
				  ,[Customer_Fax] = '".$_POST['Customer_Fax']."'
				  ,[Customer_Email] = '".$_POST['Customer_Email']."'
				  ,[Customer_RegisDate] = '".$_POST['Customer_RegisDate']."'
				  ,[Customer_ExpireDate] = '".$_POST['Customer_ExpireDate']."'
				  ,[Customer_PromotionAccount] = '".$_POST['Customer_PromotionAccount']."'
				  ,[Customer_PromotionMonth] = '".$_POST['Customer_PromotionMonth']."'
				  ,[Customer_DR] = '".$_POST['Customer_DR']."'
				  ,[Customer_Remark] = '".$_POST['Customer_Remark']."'
			 WHERE Customer_ID='".$_POST['Request_ID']."'";
		mssql_query($sql);
		//mssql_query("UPDATE SBG_Senders SET Sender_Name='".$_POST['Sender_Name1']."' WHERE Sender_ID='".$_POST['Sender_ID']."'"); //Edited by Boom
		

		$ext="pg-customer";
		header("refresh: 0; url=result.php?nextPage=index&ext=$ext");
		
		}else if($_POST['method']=="remove"&&$_POST['Request_Sender']){
		$sql="DELETE FROM SBG_Senders WHERE Sender_ID='".$_POST['Request_Sender']."'";
		$objQuery=mssql_query($sql);
			if($objQuery){
?>			
				<script>alert('Delete successfully!\nPlease refresh your page with F5');</script>
<?				
			}else{
?>			
				<script>alert('Error! Cannot Delete');</script>
<?				
			}
		$ext="pg-customer";
		header("refresh: 0; url=result.php?nextPage=index&ext=$ext");
		}
		

		else if($_POST['method']=="add"&&$_POST['Request_ID']){
			//echo $a[0].$a[1].$a[2]$a[3].$a[4];		
			//if((empty($a[0]))&&(empty($a[1]))&&(empty($a[2]))&&(empty($a[3]))&&(empty($a[4]))){
?>	
				<!--<script>alert('Please fill some Sender Name');</script>-->
<?					
			//}
			
			
			//else{
				$sql="SELECT Sender_Name FROM SBG_Senders WHERE Customer_ID='".$_POST['Request_ID']."' AND Sender_Name='".$_POST['Sender_Name']."'";
				$check=mssql_query($sql);
				$result=mssql_fetch_array($check);
				if(!$result){
					$sql="INSERT INTO SBG_Senders (Sender_Name, Customer_ID) VALUES ('".$_POST['Sender_Name']."','".$_POST['Request_ID']."')";
					$objQuery=mssql_query($sql);
					if($objQuery){
?>			
						<script>alert('Add successfully!\nPlease refresh your page with F5');</script>
<?
					}
					else{
						echo "<script>alert('Error!');</script>";
					}
				}
				else{
					echo "<script>alert('Duplicate Sender Name Exists!');</script>";
				}
			//}
		
		$ext="pg-customer";
				header("refresh: 0; url=result.php?nextPage=index&ext=$ext");
		}/////////////////////error!!!
						
	else if($_POST['method']=="delete"&&$_POST['Customer_Account']){
		$sql_file="SELECT Group_ID FROM SBG_Groups WHERE Customer_ID='".$_POST['Request_ID']."' AND Group_Method='F'";
		$mssql_file=mssql_query($sql_file);
		while($data_file=mssql_fetch_array($mssql_file)){
			$file_name = "files/".md5($_POST['Request_ID']."_".$data_file['Group_ID']).".txt";
			if(file_exists($file_name)){
				unlink($file_name);
				//echo $file_name."<br>";
			}
		}
		$sql="DELETE FROM SBG_Customers WHERE Customer_ID='".$_POST['Request_ID']."'";
		mssql_query($sql);
		//Edited by Boom
		mssql_query("DELETE FROM SBG_Senders WHERE Customer_ID='".$_POST['Request_ID']."'"); //delete customer, delete sender too
		//Edited by Boom
		$ext="pg-customer";
		header("refresh: 0; url=result.php?nextPage=index&ext=$ext");
	}else if($_POST['method']=="reset"&&$_POST['Customer_Account']){
		$sql="UPDATE SBG_Customers
			   SET [Customer_Password] = '".md5(substr($_POST['Customer_No'],-4,4))."'
			 WHERE Customer_ID='".$_POST['Request_ID']."'";
		mssql_query($sql);
		$ext="pg-customer";
		header("refresh: 0; url=result.php?nextPage=index&ext=$ext");
	}
	/*
			else if($status == "DELETE")
		//if($request->getParameter('delete_sender')!=null)
		{
			$sql_3=mssql_query=("DELETE FROM SBG_Senders WHERE Sender_ID='".$edit_2['Sender_ID']."'");
			
		}	
	*/	
	
	
	else{
		$ext="";
		header("refresh: 0; url=result.php?nextPage=index&ext=$ext&status=error");
	}
}else{
	$ext="";
	header("refresh: 0; url=result.php?nextPage=index&ext=$ext&status=error");
}
ob_end_flush();
?>