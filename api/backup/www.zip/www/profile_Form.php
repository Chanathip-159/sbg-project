<? include("config.php");?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<script language="javascript" type="text/javascript">
<!--  
function ValidateProfile(form){
	var emailFilter = /^.+@.+\..{2,3}$/; //email regular expression
	var email = document.formEdit.Customer_Email.value;
	var telFilter = /^\d{9,10}(,\d{9,10})*$/; //tel fax regular expression /^0[0-9]{9}([^,]*)$/
	var tel = document.formEdit.Customer_Telephone.value;
	var fax = document.formEdit.Customer_Fax.value;
	if (form.Customer_Title.value == ""){
		alert("Your title is required!");
		form.Customer_Title.focus();
		return false;
	}  
	if (form.Customer_Contact.value == ""){
		alert("Your contact is required!");
		form.Customer_Contact.focus();
		return false;
	}  
	if (form.Customer_Address.value == ""){
		alert("Your address is required!");
		form.Customer_Address.focus();
		return false;
	}  
	if (form.Customer_Email.value == ""){
		alert("Your e-mail is required!");
		form.Customer_Email.focus();
		return false;
	} 
	if (!(emailFilter.test(email))){
		alert("Not a valid e-mail address");
		form.Customer_Email.focus();
		return false;
	}
	if (form.Customer_Telephone.value == ""){
		alert("Your telephone is required!");
		form.Customer_Telephone.focus();
		return false;
	}
	if (!(telFilter.test(tel))){
		alert("Not a valid telephone, please input only number 9-10 digits or comma (,) or dash (-)");
		form.Customer_Telephone.focus();
		return false;
	}
	if (!(telFilter.test(fax))){
		alert("Not a valid fax, please input only number 9-10 digits or comma (,) or dash (-)");
		form.Customer_Fax.focus();
		return false;
	}
	return true;
}  
//--> 
</script><br /><br />
<?
if(!empty($_SESSION['Customer_ID'])){
	$sql ="SELECT * FROM SBG_Customers WHERE Customer_ID='".$_SESSION['Customer_ID']."'";
	$mssql = mssql_query($sql);
	$edit = mssql_fetch_array($mssql);
?>
    <form name="formEdit" action="profile_Query.php" method="post" onsubmit="return ValidateProfile(this)">
      <table cellpadding="1" cellspacing="1" bgcolor="<?=$bg_form?>" align="center"><tr>
        <td align="center" class="tx_sub_head">Profile Form</td></tr><tr>
          <td>
        <table width="550" align="center" bgcolor="#FFFFFF">
          <tr>
            <td width="3%">&nbsp;</td>
            <td width="25%">&nbsp;</td>
            <td width="2%">&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td height="25">&nbsp;</td>
            <td>Account</td>
            <td>:</td>
            <td><?=$edit['Customer_Account']?></td>
          </tr>
            <tr>
              <td height="25">&nbsp;</td>
                <td>Title</td>
                <td>:</td>
                <td><input name="Customer_Title" type="text" size="50" value="<?=$edit['Customer_Title']?>" />
                *</td>
            </tr>
            <tr>
              <td height="25">&nbsp;</td>
                <td>Contact</td>
                <td>:</td>
                <td><input name="Customer_Contact" type="text" size="50" value="<?=$edit['Customer_Contact']?>" />
                *</td>
            </tr>
            <tr>
              <td height="25" valign="top">&nbsp;</td>
                <td valign="top">Address</td>
                <td valign="top">:</td>
                <td><textarea name="Customer_Address" cols="40" rows="5"><?=$edit['Customer_Address']?></textarea>
                *</td>
            </tr>
            <tr>
              <td height="25">&nbsp;</td>
                <td>Email</td>
                <td>:</td>
              <td><input name="Customer_Email" type="text" size="40" value="<?=$edit['Customer_Email']?>" />
              *</td>
            </tr>
            <tr>
              <td height="25">&nbsp;</td>
                <td>Telephone</td>
                <td>:</td>
                <td><input name="Customer_Telephone" type="text" size="40" value="<?=$edit['Customer_Telephone']?>" />
                *</td>
            </tr>
            <tr>
              <td height="25">&nbsp;</td>
                <td>Fax</td>
                <td>:</td>
                <td><input name="Customer_Fax" type="text" size="40" value="<?=$edit['Customer_Fax']?>" /></td>
            </tr>
            <tr>
              <td height="25">&nbsp;</td>
              <td>Limit Account</td>
              <td>:</td>
              <td>
				  <?
                  if($edit['Customer_PromotionAccount']==-1){
					  echo "No limit";
				  }else{
					  echo number_format($edit['Customer_PromotionAccount'],0);
				  }
				  ?>
              </td>
            </tr>
            <tr>
              <td height="25">&nbsp;</td>
              <td>Limit Month</td>
              <td>:</td>
              <td>
				  <?
                  if($edit['Customer_PromotionMonth']==-1){
					  echo "No limit";
				  }else{
					  echo number_format($edit['Customer_PromotionMonth'],0);
				  }
				  ?>
              </td>
            </tr>
            <tr>
              <td height="25">&nbsp;</td>
              <td>Current usage</td>
              <td>:</td>
              <td><?=number_format($edit['Customer_AllCurrentUsage'],0)?></td>
            </tr>
            <tr>
              <td height="25">&nbsp;</td>
              <td>Registation Date</td>
              <td>:</td>
              <td><?=substr($edit['Customer_RegisDate'],0,19)?></td>
          </tr>
            <tr>
              <td height="25">&nbsp;</td>
              <td>Expire Date</td>
              <td>:</td>
              <td><?=substr($edit['Customer_ExpireDate'],0,19)?></td>
          </tr>
            <tr>
              <td height="25">&nbsp;</td>
              <td>Create Date</td>
              <td>:</td>
              <td><?=substr($edit['Customer_CreateDate'],0,19)?></td>
            </tr>
            <tr>
              <td height="25">&nbsp;</td>
              <td>Revise Date</td>
              <td>:</td>
              <td><?=substr($edit['Customer_UpDate'],0,19)?></td>
            </tr>
			<tr>
              <td height="25">&nbsp;</td>
                <td>Remark</td>
                <td>:</td>
                <td><textarea name="Customer_Remark" cols="40" rows="5" disabled><?=$edit['Customer_Remark']?></textarea></td>
            </tr>
            <tr>
              <td height="50" colspan="4" align="center"><input type="hidden" name="method" value="edit" />
                <input type="submit" name="Submit" value="Submit" /></td>
          </tr>
        </table>
        </td></tr></table>
    </form>
<? }else if(!empty($_SESSION['Admin_ID'])){
	$sql ="SELECT * FROM SBG_Admins WHERE Admin_ID='".$_SESSION['Admin_ID']."'";
	$mssql = mssql_query($sql);
	$edit = mssql_fetch_array($mssql);
?>
    <form name="formEdit" action="profile_Query.php" method="post" onsubmit="return ValidateProfile(this)">
      <table cellpadding="1" cellspacing="1" bgcolor="<?=$bg_form?>" align="center"><tr>
        <td align="center" class="tx_sub_head">Profile Form</td></tr><tr><td>
        <table width="500" align="center" bgcolor="#FFFFFF">
          <tr>
            <td width="3%">&nbsp;</td>
            <td width="25%">&nbsp;</td>
            <td width="2%">&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>Account</td>
            <td>:</td>
            <td><?=$edit['Admin_Account']?></td>
          </tr>
            <tr>
              <td>&nbsp;</td>
                <td>Department</td>
                <td>:</td>
                <td><input name="Admin_Department" type="text" size="40" value="<?=$edit['Admin_Department']?>" /></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
                <td>Fullname</td>
                <td>:</td>
                <td><input name="Admin_FullName" type="text" size="30" value="<?=$edit['Admin_FullName']?>" /></td>
            </tr>
            <tr>
              <td height="50" colspan="4" align="center"><input type="hidden" name="method" value="edit" />
                <input type="submit" name="Submit" value="Submit" /></td>
            </tr>
        </table>
        </td></tr></table>
    </form>
<? }?>
<br /><br />
