<? include("config.php");?>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<script language="javascript" type="text/javascript">
<!--  
function ValidateGroup(form){
	var FileName  = form.file.value;
	var FileExt = FileName.substr(FileName.lastIndexOf('.')+1);
	var FileSize = form.file.files[0].size;
	var FileSizeKB = (FileSize/1024).toFixed(2);
	
	if (form.Group_Title.value == ""){
		alert("Your group title is required!");
		form.Group_Title.focus();
		return false;
	}
	if (form.file.value == ""){
		alert("Your file is required!");
		form.file.focus();
		return false;
	}
	if (FileExt!="txt" || FileSize>241664){
		var error = "File type : "+ FileExt+"\n";
		error += "Size: " + FileSizeKB + " KB \n";
		error += "Please make sure your file is in txt and less than 236 KB.\n\n";
		alert(error);
		return false;
    }
	return true;
}  
function toggle() {
    var ele = document.getElementsByName("rowfile");
    for (var i = 0; i < ele.length; i++) {
        if (ele[i].style.display == "block") { 
            ele[i].style.display = "none";
        }else {
            ele[i].style.display = "block";
        }
    }
}
//--> 
</script>
<style type="text/css" title="currentStyle">
@import "DataTable/css/demo_page.css";
 @import "DataTable/css/demo_table.css";
</style>
<script type="text/javascript" language="javascript" src="DataTable/js/jquery.js"></script>
<script type="text/javascript" language="javascript" src="DataTable/js/jquery.dataTables.js"></script>
<script type="text/javascript" charset="utf-8">
	$.fn.dataTableExt.oApi.fnGetHiddenTrNodes = function ( oSettings ){
		var anNodes = this.oApi._fnGetTrNodes( oSettings );
		var anDisplay = $('tbody tr', oSettings.nTable);
		for ( var i=0 ; i<anDisplay.length ; i++ ){
			var iIndex = jQuery.inArray( anDisplay[i], anNodes );
			if ( iIndex != -1 ){
				anNodes.splice( iIndex, 1 );
			}
		}
		return anNodes;
	}
	var oTable;
	/*
	$(document).ready(function() {
		var oTable = $('#example').dataTable();
		$('#button').click( function () {
			var nHidden = oTable.fnGetHiddenTrNodes( );
			alert( nHidden.length +' nodes were returned' );
		} );
	} );
	*/
	$(document).ready(function() {
		$('#example').dataTable( {
		"iDisplayLength": 25,
		"aLengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]]
		} );
	} );
</script>

<link type="text/css" href="jquery.calendars/humanity.calendars.picker.css" rel="stylesheet"/>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.min.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.plus.min.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.picker.min.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.thai.min.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.thai-th.js"></script>
<script type="text/javascript" src="jquery.calendars/jquery.calendars.picker-th.js"></script>
<script type="text/javascript">
$(function() {
	$('#RegisDate').calendarsPicker({ minDate: "-12M -0D", maxDate:0, dateFormat:"yyyy-mm-dd", calendar: $.calendars.instance('thai','th')});
	$('#ExpireDate').calendarsPicker({ minDate: "-12M -0D", maxDate:"+12M +0D", dateFormat:"yyyy-mm-dd", calendar: $.calendars.instance('thai','th')});
});

</script>

<?
$sql ="SELECT g.Group_ID, Group_Method, Group_Title, Group_Description, Group_CreateDate, Group_TotalFileNumbering, COUNT(Number_No) AS Total FROM SBG_Groups g LEFT JOIN SBG_Numberings n ON g.Group_ID=n.Group_ID WHERE Customer_ID='".$_SESSION['Customer_ID']."' GROUP BY g.Group_ID, Group_Method, Group_Title, Group_Description, Group_CreateDate, Group_TotalFileNumbering ORDER BY Group_Title";
$mssql = mssql_query($sql);
$rows = mssql_num_rows($mssql);
if(empty($_POST['create'])&&empty($_POST['edit'])&&empty($_POST['delete'])&&empty($_POST['check_file'])){
?>
    <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
      <form name="formCreateButton" action="<? $PHP_SELF?>" method="post">
      <tr>
        <td valign="top" class="tx_sub_head">Groups</td>
        <td align="right" class="tx_sub_head">
        <? if($rows<100){$group_balance=100-$rows;?>
        <input type="submit" class="button_form" name="create" value="Create group (Remain <?=$group_balance?> groups)" />
        <? }?>
        </td>
      </tr>
      </form>
    </table>
    <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td colspan="2"><div id="demo">
            <table cellpadding="0" cellspacing="0" border="0" class="display" id="example">
              <thead>
                <tr>
                  <th>No.</th>
                  <th>Method</th>
                  <th>Name</th>
                  <th>Total of numberings</th>
                  <th>Create</th>
                  <th>Numberings</th>
                  <th>Send SMS</th>
                  <th>Edit</th>
                  <th>Del.</th>
                </tr>
              </thead>
              <tbody>
              <? $i=0;while($data=mssql_fetch_array($mssql)){ $i++;?>
                <tr class="<?=$bg?>" onMouseOver="this.bgColor='#FFFFFF';" onMouseOut="this.bgColor='<?=$bg?>';">
                  <td align="center"><?=$i?></td>
                  <td><?
				  	if($data['Group_Method']=="D"){
                  		echo "System";
					}else if($data['Group_Method']=="F"){
                  		echo "File";
					}
				  ?></td>
                  <td><?=$data['Group_Title']?></td>
                  <td align="center"><? 
				  if($data['Group_Method']=="D"){
                  	echo number_format($data['Total'],0);
                  }else if($data['Group_Method']=="F"){
					echo number_format($data['Group_TotalFileNumbering'],0);
				  }?></td>
                  <td align="center"><?=substr($data['Group_CreateDate'],0,16)?></td>
                  <form name="formEditButton" action="index.php?pg=number" method="post">
                  <td align="center">
                  <input type="hidden" name="Group_ID" value="<?=$data['Group_ID']?>" />
                  <input type="hidden" name="Group_Title" value="<?=$data['Group_Title']?>" />
                  <? if($data['Group_Method']=="D"){?>
                  <input type="image" src="image/folder.gif" />
                  <? }else if($data['Group_Method']=="F"){$file="files/".md5($_SESSION['Customer_ID']."_".$data['Group_ID']).".txt";?>
                  	<? if(!file_exists($file)){?>
                    	File not found
                    <? }else{?>
                  		<a href=<?=$file?> target="_blank"><img src="image/txt.gif" border="0" /></a>
                  	<? }?>
                  <? }?>
                  </td>
                  </form>
                  <form name="formSendGroup" action="index.php?pg=sendGroup" method="post">
                  <td align="center">
                  <input type="hidden" name="Group_ID" value="<?=$data['Group_ID']?>" />
                  <input type="hidden" name="Group_Title" value="<?=$data['Group_Title']?>" />
                  <input type="hidden" name="Group_Method" value="<?=$data['Group_Method']?>" />
                  <input type="hidden" name="Group_TotalFileNumbering" value="<?=$data['Group_TotalFileNumbering']?>" />
                  <input type="hidden" name="Group_TotalNumber" value="<?=$data['Total']?>" />
                  <input type="hidden" name="Group_Path" value="<?=$file?>" />
                  <? if(($data['Group_Method']=="D"&&$data['Total']>0)||($data['Group_Method']=="F"&&file_exists($file))){?>
                  <input type="image" src="image/sms.gif" />
                  <? }else{?>
                  -
                  <? }?>
                  </td>
                  </form>
                  <form name="formEditButton" action="<? $PHP_SELF?>" method="post">
                  <td align="center">
                  <input type="hidden" name="Group_ID" value="<?=$data['Group_ID']?>" />
                  <input type="image" src="image/edit.gif" name="edit" value="Edit" />
                  </td>
                  </form>
                  <form name="formDeleteButton" action="group_Query.php" method="post">
                  <td align="center">
                  <input type="hidden" name="Group_ID" value="<?=$data['Group_ID']?>" />
                  <input type="hidden" name="method" value="delete" />
                  <input type="image" src="image/delete.gif" name="delete" value="Delete" onclick="return confirm('Are you sure you want to delete this?')" />
                  </td> 
                  </form>
                </tr>
               <? }?>
            </table>
          </div>
          <div class="spacer"></div></td>
      </tr>
    </table>
	<? }else{echo "<br><br>";
		if(!empty($_POST['create'])&&$rows<100){?>
    	<form name="form" action="group_Query.php" method="post" onsubmit="return ValidateGroup(this)" enctype="multipart/form-data">
    	<table cellpadding="1" cellspacing="1" bgcolor="<?=$bg_form?>" align="center"><tr>
    	<td align="center" class="tx_sub_head">Group create form</td></tr><tr><td>
        <table width="500" bgcolor="#FFFFFF">
        	<tr>
        	  <td width="3%">&nbsp;</td>
        	  <td width="25%">&nbsp;</td>
        	  <td width="2%">&nbsp;</td>
        	  <td>&nbsp;</td>
      	    </tr>
        	<tr>
        	  <td>&nbsp;</td>
        	  <td>Method</td>
        	  <td>:</td>
        	  <td>
              <select name="Group_Method" onchange="javascript:toggle();">
              	<option value="D">System</option>
                <option value="F">File</option>
              </select>
              </td>
      	  </tr>
        	<tr>
        	  <td>&nbsp;</td>
            	<td>Name</td>
            	<td>:</td>
            	<td><input name="Group_Title" type="text" size="45" />
            	  *</td>
            </tr>
        	<tr>
        	  <td>&nbsp;</td>
            	<td>Description</td>
            	<td>:</td>
            	<td><input name="Group_Description" type="text" size="45" /></td>
            </tr>
            <tr>
              <td colspan="4">
              <table width="100%" border="0" name="rowfile" style="display:none" align="center">
                  <tr>
                    <td align="center">File : <input type="file" name="file"/></td>
                  </tr>
                  <tr>
                    <td height="50" align="center">Format type must be only text file (.txt) and maximum size 60 KB.<br />
                    Data format  is incorrect, data format is mobile number 10 digits only<br />
                    for example<br />
                    0860900000<br />
                    0860905555<br />
                    0800907777</td>
                  </tr>
              </table>
              </td>
            </tr>
        	<tr>
        	  <td height="50" colspan="4" align="center">
       	      <input type="hidden" name="method" value="create" />
              <input type="hidden" name="Rows" value="<?=$rows?>" />
              <input type="hidden" name="Customer_ID" value="<?=$_POST['Customer_ID']?>" />
              <input type="submit" name="Submit" value="Submit" />
              </td>
       	    </tr>
        </table>
        </td></tr></table>
        </form>
    <? 
	}else if(!empty($_POST['edit'])){
		$edit=mssql_fetch_array(mssql_query("SELECT * FROM SBG_Groups WHERE Group_ID='".$_POST['Group_ID']."'"));
	?>
    	<form name="form" action="group_Query.php" method="post" onsubmit="return ValidateGroup(this)" enctype="multipart/form-data">
    	<table cellpadding="1" cellspacing="1" bgcolor="<?=$bg_form?>" align="center"><tr>
    	<td align="center" class="tx_sub_head">Group edit form</td></tr><tr><td>
        <table width="500" align="center" bgcolor="#FFFFFF">
          <tr>
            <td width="3%">&nbsp;</td>
            <td width="25%">&nbsp;</td>
            <td width="2%">&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        	<tr>
        	  <td>&nbsp;</td>
        	  <td>Method</td>
        	  <td>:</td>
        	  <td><?
				  	if($edit['Group_Method']=="D"){
                  		echo "System";
					}else if($edit['Group_Method']=="F"){
                  		echo "File";
					}
				  ?>
              </td>
      	  </tr>
        	<tr>
        	  <td>&nbsp;</td>
            	<td>Name</td>
            	<td>:</td>
            	<td><input name="Group_Title" type="text" size="45" value="<?=$edit['Group_Title']?>" />
            	  *</td>
            </tr>
        	<tr>
        	  <td>&nbsp;</td>
            	<td>Description</td>
            	<td>:</td>
            	<td><input name="Group_Description" type="text" size="45" value="<?=$edit['Group_Description']?>" /></td>
            </tr>
            <? if($edit['Group_Method']=="F"){?>
        	<tr>
        	  <td height="25">&nbsp;</td>
        	  <td valign="top">File</td>
        	  <td valign="top">:</td>
        	  <td><input type="file" name="file" /></td>
            </tr>
        	<tr>
        	  <td height="50" colspan="4" align="center">Format type must be only text file (.txt) and maximum size 60 KB.<br />
        	    Data format  is incorrect, data format is mobile number 10 digits only<br />
        	    for example<br />
        	    0860900000<br />
        	    0860905555<br />
       	      0800907777</td>
      	  </tr>
            <? }?>
        	<tr>
        	  <td height="25">&nbsp;</td>
        	  <td>Create Date</td>
        	  <td>:</td>
        	  <td><?=substr($edit['Group_CreateDate'],0,19)?></td>
      	  </tr>
        	<tr>
        	  <td height="25">&nbsp;</td>
        	  <td>Revise Date</td>
        	  <td>:</td>
        	  <td><?=substr($edit['Group_UpDate'],0,19)?></td>
      	  </tr>
        	<tr>
        	  <td height="50" colspan="4" align="center">
              <input type="hidden" name="Group_ID" value="<?=$edit['Group_ID']?>" />
              <input type="hidden" name="method" value="edit" />
       	      <input type="submit" name="Submit" value="Submit" />
              </td>
      	  </tr>
        </table>
        </td></tr></table>
        </form>
     <? }?>
<? echo "<br><br>";}?>